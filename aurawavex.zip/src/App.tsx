import React, { useState, useEffect, useRef } from "react";
import {
  Play,
  Pause,
  SkipForward,
  SkipBack,
  Sliders,
  Volume2,
  Folder,
  FileCode,
  Copy,
  Check,
  CheckCircle2,
  Settings as SettingsIcon,
  Music as MusicIcon,
  Activity,
  Cpu,
  Info,
  Smartphone,
  ChevronRight,
  ChevronDown,
  Download,
  AlertCircle
} from "lucide-react";
import { sourceProject, SourceFile, SourceDir } from "./sourceCode";

// Define local structures representing simulated states
interface Song {
  id: string;
  title: string;
  artist: string;
  album: string;
  durationSeconds: number;
  sampleRateHz: number;
  bitDepth: number;
  fileFormat: string;
  kbps: number;
  coverColor: string;
}

const trackList: Song[] = [
  {
    id: "track_1",
    title: "Aether Waves",
    artist: "Luminance Duo",
    album: "Quantum Echoes",
    durationSeconds: 342,
    sampleRateHz: 192000,
    bitDepth: 24,
    fileFormat: "FLAC",
    kbps: 5820,
    coverColor: "from-cyan-900 to-slate-900"
  },
  {
    id: "track_2",
    title: "Nebula Dreams",
    artist: "Cosmic Synthesis",
    album: "Stellar Audio Experience",
    durationSeconds: 485,
    sampleRateHz: 352800,
    bitDepth: 32,
    fileFormat: "WAV",
    kbps: 9216,
    coverColor: "from-purple-950 to-slate-900"
  },
  {
    id: "track_3",
    title: "Absolute Horizon",
    artist: "Vortex Field",
    album: "HoloCore Showcase Vol. I",
    durationSeconds: 294,
    sampleRateHz: 2822400, // DSD64
    bitDepth: 1,
    fileFormat: "DSD",
    kbps: 5644,
    coverColor: "from-teal-950 to-slate-900"
  }
];

export default function App() {
  // Navigation: "splash" | "home" | "music" | "holocore" | "eq" | "analyzer" | "settings"
  const [activeTab, setActiveTab] = useState<string>("splash");
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [currentSongIndex, setCurrentSongIndex] = useState<number>(0);
  const [progress, setProgress] = useState<number>(42);
  
  // DAC settings
  const [volume, setVolume] = useState<number>(85);
  const [isBitPerfect, setIsBitPerfect] = useState<boolean>(true);
  const [activeDriver, setActiveDriver] = useState<string>("HoloCore™ Bit-Perfect USB");
  const [activeFilter, setActiveFilter] = useState<string>("Minimum Phase (Fast)");
  const [mqaStatus, setMqaStatus] = useState<string>("MQA Studio Decoder");

  // Project Code Inspector State
  const [selectedFile, setSelectedFile] = useState<SourceFile | null>(null);
  const [expandedNodes, setExpandedNodes] = useState<Record<string, boolean>>({
    "AuraWaveX Project": true,
    "app": true,
    "java/com/aurawavex/app": true,
    "ui": true,
    "theme": true,
    "screens": true,
    "viewmodel": true,
    "model": true,
    "navigation": true,
    "build-system": true
  });
  const [copiedFile, setCopiedFile] = useState<boolean>(false);

  const currentSong = trackList[currentSongIndex];

  // Auto transition splash screen
  useEffect(() => {
    if (activeTab === "splash") {
      const timer = setTimeout(() => {
        setActiveTab("home");
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [activeTab]);

  // Simulated song progress ticking
  useEffect(() => {
    let interval: any;
    if (isPlaying && activeTab !== "splash") {
      interval = setInterval(() => {
        setProgress((prev) => {
          if (prev >= currentSong.durationSeconds) {
            // Next track
            setCurrentSongIndex((prevIndex) => (prevIndex + 1) % trackList.length);
            return 0;
          }
          return prev + 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isPlaying, currentSong, activeTab]);

  // Set default code file
  useEffect(() => {
    if (!selectedFile) {
      // Find MainActivity.kt
      const findMainActivity = (dir: SourceDir): SourceFile | null => {
        for (const file of dir.files) {
          if (file.name === "MainActivity.kt") return file;
        }
        if (dir.subdirs) {
          for (const s of dir.subdirs) {
            const found = findMainActivity(s);
            if (found) return found;
          }
        }
        return null;
      };
      const file = findMainActivity(sourceProject);
      if (file) setSelectedFile(file);
    }
  }, [selectedFile]);

  // Canvas ref for real-time waveform animation
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationFrameId: number;
    let phase = 0;

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const width = canvas.width;
      const height = canvas.height;
      const centerY = height / 2;

      // Draw background styling
      ctx.fillStyle = "rgba(0, 229, 255, 0.02)";
      ctx.fillRect(0, 0, width, height);

      if (isPlaying) {
        phase += 0.08;
      }

      // Draw three layers of luxury overlapping sine waves with glowing gradients
      const drawWave = (amplitude: number, freq: number, phaseOffset: number, color: string, lineWidth: number) => {
        ctx.beginPath();
        ctx.strokeStyle = color;
        ctx.lineWidth = lineWidth;
        ctx.lineCap = "round";

        for (let x = 0; x < width; x++) {
          const relativeX = x / width;
          // Apply a bell curve envelope so the wave fades smoothly at the edges
          const envelope = Math.sin(relativeX * Math.PI);
          const y = centerY + Math.sin(relativeX * freq * Math.PI + phase + phaseOffset) * amplitude * envelope * (isPlaying ? 1 : 0.1);
          if (x === 0) {
            ctx.moveTo(x, y);
          } else {
            ctx.lineTo(x, y);
          }
        }
        ctx.stroke();
      };

      // Bottom glow layer
      drawWave(25, 2.5, 0, "rgba(142, 36, 170, 0.4)", 3);
      // Mid Cyan layer
      drawWave(18, 3.8, Math.PI / 3, "rgba(0, 229, 255, 0.5)", 2);
      // Sharp Foreground active line
      drawWave(12, 5.0, -Math.PI / 4, "rgba(0, 229, 255, 0.95)", 2.5);

      animationFrameId = requestAnimationFrame(render);
    };

    render();
    return () => cancelAnimationFrame(animationFrameId);
  }, [isPlaying, activeTab]);

  // Fast Fourier Transform analyzer canvas
  const analyzerCanvasRef = useRef<HTMLCanvasElement | null>(null);
  useEffect(() => {
    if (activeTab !== "analyzer") return;
    const canvas = analyzerCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationFrameId: number;
    const barCount = 36;
    const barHeights = Array(barCount).fill(0).map(() => Math.random() * 80);

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const width = canvas.width;
      const height = canvas.height;
      const spacing = 4;
      const barWidth = (width - spacing * (barCount - 1)) / barCount;

      for (let i = 0; i < barCount; i++) {
        // Smooth transition target heights
        if (isPlaying) {
          const target = Math.max(10, Math.sin(i / 4 + Date.now() / 200) * 45 + 50 + Math.random() * 25);
          barHeights[i] += (target - barHeights[i]) * 0.15;
        } else {
          barHeights[i] += (4 - barHeights[i]) * 0.1;
        }

        const h = (barHeights[i] / 120) * height;
        const x = i * (barWidth + spacing);
        const y = height - h;

        // Draw luxury gradient bar with rounded corners
        const grad = ctx.createLinearGradient(x, y, x, height);
        grad.addColorStop(0, "#00E5FF"); // Cyan top
        grad.addColorStop(0.5, "#8E24AA"); // Purple mid
        grad.addColorStop(1, "rgba(0,0,0,0.2)"); // Translucent bottom

        ctx.fillStyle = grad;
        
        // Draw standard round top bar
        ctx.beginPath();
        ctx.roundRect(x, y, barWidth, h, [3, 3, 0, 0]);
        ctx.fill();
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();
    return () => cancelAnimationFrame(animationFrameId);
  }, [isPlaying, activeTab]);

  // Copy code utility
  const handleCopyCode = () => {
    if (!selectedFile) return;
    navigator.clipboard.writeText(selectedFile.content);
    setCopiedFile(true);
    setTimeout(() => setCopiedFile(false), 2000);
  };

  const toggleNode = (nodeName: string) => {
    setExpandedNodes((prev) => ({
      ...prev,
      [nodeName]: !prev[nodeName]
    }));
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s < 10 ? "0" : ""}${s}`;
  };

  // Render directory tree recursively
  const renderTree = (dir: SourceDir) => {
    const isExpanded = expandedNodes[dir.name];
    return (
      <div key={dir.name} className="pl-3 select-none">
        <div
          onClick={() => toggleNode(dir.name)}
          className="flex items-center gap-1.5 py-1 px-1.5 rounded hover:bg-slate-800/60 cursor-pointer text-slate-300 transition-colors"
        >
          {isExpanded ? (
            <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
          ) : (
            <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
          )}
          <Folder className="w-4 h-4 text-cyan-400/80 fill-cyan-400/10" />
          <span className="font-sans text-xs font-medium">{dir.name}</span>
        </div>

        {isExpanded && (
          <div className="border-l border-slate-800/80 ml-3 pl-1">
            {dir.subdirs && dir.subdirs.map((s) => renderTree(s))}
            {dir.files.map((f) => {
              const isSelected = selectedFile?.path === f.path;
              return (
                <div
                  key={f.path}
                  onClick={() => setSelectedFile(f)}
                  className={`flex items-center gap-2 py-1 px-2 rounded cursor-pointer transition-all ${
                    isSelected
                      ? "bg-cyan-500/10 text-cyan-400 border-l-2 border-cyan-400 pl-1.5"
                      : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/40"
                  }`}
                >
                  <FileCode className="w-3.5 h-3.5 text-slate-500" />
                  <span className="font-mono text-xs">{f.name}</span>
                </div>
              );
            })}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-black text-white font-sans antialiased overflow-x-hidden flex flex-col relative">
      {/* Elegant Dark Ambient Glows */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-purple-900/20 rounded-full blur-[120px]"></div>
        <div className="absolute bottom-[-5%] right-[-5%] w-[50%] h-[50%] bg-blue-900/20 rounded-full blur-[120px]"></div>
      </div>

      {/* Flagship Header */}
      <header className="border-b border-white/5 bg-zinc-950/40 backdrop-blur-xl sticky top-0 z-50 px-6 py-4">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-3">
              <span className="bg-gradient-to-r from-cyan-500/10 to-purple-500/10 border border-cyan-500/30 text-cyan-300 text-[10px] font-bold tracking-widest px-2.5 py-0.5 rounded-full uppercase shadow-[inset_0_0_12px_rgba(6,182,212,0.1)]">
                Studio Blueprint
              </span>
              <span className="text-zinc-500 text-xs font-mono">v1.0.0-PRO</span>
            </div>
            <h1 className="text-2xl font-bold tracking-tighter bg-clip-text text-transparent bg-gradient-to-r from-white to-zinc-500 mt-1">
              AuraWaveX <span className="font-light text-zinc-500">Powered by HoloCore™</span>
            </h1>
            <p className="text-xs text-zinc-400 mt-0.5">
              Premium high-end Android audiophile application foundation. Developed by <span className="text-cyan-400 font-medium">Chrissy Godwin</span>.
            </p>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 bg-zinc-950 border border-white/5 px-3 py-1.5 rounded-lg text-[11px] font-mono text-zinc-400 shadow-[inset_0_0_8px_rgba(255,255,255,0.02)]">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse shadow-[0_0_8px_#22d3ee]"></span>
              DEV ENVIRONMENT: PORT 3000
            </div>
            <a
              href="#project-files"
              className="bg-zinc-900/40 hover:bg-zinc-800/60 text-xs font-semibold px-4 py-2 rounded-lg transition-all flex items-center gap-2 text-zinc-200 border border-white/5 backdrop-blur-xl"
            >
              <FileCode className="w-3.5 h-3.5" />
              Browse Kotlin Code
            </a>
          </div>
        </div>
      </header>

      {/* Main Workspace Splitter */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start relative z-10">
        
        {/* LEFT COLUMN: Premium Interactive Android Device Mockup (lg:col-span-5) */}
        <div className="lg:col-span-5 flex flex-col items-center">
          
          <div className="text-center mb-4">
            <span className="text-xs font-semibold text-zinc-400 flex items-center justify-center gap-1.5 uppercase tracking-widest">
              <Smartphone className="w-4 h-4 text-cyan-400" />
              120Hz Audiophile Flagship Emulator
            </span>
          </div>

          {/* Premium Device Chassis */}
          <div className="relative w-full max-w-[370px] aspect-[9/19] rounded-[48px] bg-black border-[6px] border-zinc-900 shadow-[0_24px_80px_rgba(0,0,0,0.8),0_0_0_1px_rgba(255,255,255,0.05)] p-3 overflow-hidden transition-all duration-300">
            {/* Dynamic Ambient Device Glow (Purple/Cyan aura behind chassis) */}
            <div className="absolute -inset-10 bg-gradient-to-br from-cyan-500/10 to-purple-500/10 opacity-40 blur-2xl pointer-events-none rounded-[54px]" />
            
            {/* Device Speaker Notch / Front-Facing Camera */}
            <div className="absolute top-4 left-1/2 -translate-x-1/2 w-32 h-5 bg-black rounded-full z-50 flex items-center justify-center border border-zinc-900">
              <div className="w-12 h-1 bg-zinc-850 rounded-full mb-1"></div>
              <div className="w-2.5 h-2.5 bg-black rounded-full border border-zinc-900 ml-3"></div>
            </div>

            {/* Simulated AMOLED Screen Screen Container */}
            <div className="w-full h-full bg-black rounded-[38px] overflow-hidden flex flex-col relative border border-white/5 select-none shadow-inner">
              
              {/* STATUS BAR */}
              {activeTab !== "splash" && (
                <div className="flex justify-between items-center px-6 pt-6 pb-2 text-[10px] font-mono text-zinc-400 z-40 bg-black/80 backdrop-blur-md">
                  <span>10:24 AM</span>
                  <div className="flex items-center gap-1.5">
                    <span className="text-[9px] bg-cyan-950/40 border border-cyan-800/40 text-cyan-400 px-1 rounded font-bold">BIT-PERFECT</span>
                    <span>120Hz</span>
                    <span>98%</span>
                  </div>
                </div>
              )}

              {/* SCREEN CONTENT SWITCHER */}
              <div className="flex-1 flex flex-col overflow-y-auto overflow-x-hidden relative">
                
                {/* 1. SPLASH SCREEN */}
                {activeTab === "splash" && (
                  <div className="flex-1 flex flex-col items-center justify-center bg-black p-6 text-center h-full relative z-30 animate-fade-in">
                    {/* Pulsing luxurious particle circle */}
                    <div className="relative w-44 h-44 mb-10 flex items-center justify-center">
                      {/* Purple inner core */}
                      <div className="absolute w-28 h-28 rounded-full bg-purple-900/10 border border-purple-500/10 animate-ping duration-1000" />
                      <div className="absolute w-24 h-24 rounded-full bg-zinc-900/40 border border-white/5 flex items-center justify-center shadow-lg shadow-purple-500/5 backdrop-blur-md">
                        <div className="w-16 h-16 rounded-full bg-cyan-950/30 border border-cyan-500/20 flex items-center justify-center animate-pulse">
                          <Cpu className="w-7 h-7 text-cyan-400 animate-spin-slow" />
                        </div>
                      </div>

                      {/* Floating outer glowing dots simulating particle waveform */}
                      {[...Array(8)].map((_, i) => {
                        const angle = (i * Math.PI * 2) / 8;
                        const x = Math.cos(angle) * 76;
                        const y = Math.sin(angle) * 76;
                        return (
                          <div
                            key={i}
                            className="absolute w-1.5 h-1.5 rounded-full bg-cyan-400 shadow-[0_0_8px_#00E5FF] animate-bounce"
                            style={{
                              transform: `translate(${x}px, ${y}px)`,
                              animationDelay: `${i * 150}ms`
                            }}
                          />
                        );
                      })}
                    </div>

                    <h2 className="text-2xl font-bold tracking-[0.3em] bg-clip-text text-transparent bg-gradient-to-r from-white to-zinc-500 pl-3">AURAWA VEX</h2>
                    <p className="text-[10px] tracking-[0.3em] text-cyan-400 font-bold uppercase mt-1 opacity-80">POWERED BY HOLOCORE™</p>
                    
                    <button
                      onClick={() => setActiveTab("home")}
                      className="absolute bottom-10 left-1/2 -translate-x-1/2 text-[10px] text-zinc-500 hover:text-zinc-300 font-semibold uppercase tracking-widest border border-white/5 px-4 py-2 rounded-full bg-zinc-900/40 hover:bg-zinc-900/80 transition-all cursor-pointer backdrop-blur-xl"
                    >
                      Skip Intro
                    </button>
                  </div>
                )}

                {/* 2. HOME SCREEN */}
                {activeTab === "home" && (
                  <div className="flex-1 p-5 flex flex-col justify-between animate-fade-in">
                    
                    {/* Header Branding */}
                    <div className="text-center mt-2">
                      <h3 className="text-lg font-bold tracking-[0.3em] bg-clip-text text-transparent bg-gradient-to-r from-white to-zinc-500">AURAWA VEX</h3>
                      <p className="text-[8px] font-bold text-cyan-400 tracking-[0.2em] mt-0.5 uppercase opacity-80">Powered by HoloCore™</p>
                    </div>

                    {/* Animated Audio Waveform */}
                    <div className="my-5 bg-zinc-900/20 rounded-[32px] border border-white/5 p-4 flex flex-col items-center relative overflow-hidden backdrop-blur-xl">
                      <div className="absolute top-2 left-1/2 -translate-x-1/2 text-[8px] tracking-widest text-cyan-400/80 uppercase font-medium">
                        {isPlaying ? "HoloCore™ Active Decoding Wave" : "Audio Engine Suspended"}
                      </div>
                      
                      {/* HTML5 Canvas Waveform Rendering */}
                      <canvas
                        ref={canvasRef}
                        width={300}
                        height={100}
                        className="w-full h-[84px] mt-2 rounded-lg"
                      />
                    </div>

                    {/* Sample rate & Bit depth Metrics Badges */}
                    <div className="grid grid-cols-4 gap-2 mb-4">
                      <div className="bg-zinc-900/40 border border-white/5 p-2 rounded-xl text-center backdrop-blur-xl">
                        <p className="text-[7px] text-zinc-500 font-medium tracking-wider uppercase">Rate</p>
                        <p className="text-[10px] font-bold font-mono text-white mt-0.5">
                          {currentSong.fileFormat === "DSD" ? `DSD${currentSong.sampleRateHz / 44100}` : `${currentSong.sampleRateHz / 1000} kHz`}
                        </p>
                      </div>
                      <div className="bg-zinc-900/40 border border-white/5 p-2 rounded-xl text-center backdrop-blur-xl">
                        <p className="text-[7px] text-zinc-500 font-medium tracking-wider uppercase">Depth</p>
                        <p className="text-[10px] font-bold font-mono text-white mt-0.5">
                          {currentSong.fileFormat === "DSD" ? "1-bit" : `${currentSong.bitDepth}-bit`}
                        </p>
                      </div>
                      <div className="bg-zinc-900/40 border border-white/5 p-2 rounded-xl text-center backdrop-blur-xl">
                        <p className="text-[7px] text-zinc-500 font-medium tracking-wider uppercase">Format</p>
                        <p className="text-[10px] font-bold font-mono text-cyan-400 mt-0.5">{currentSong.fileFormat}</p>
                      </div>
                      <div className="bg-zinc-900/40 border border-white/5 p-2 rounded-xl text-center backdrop-blur-xl">
                        <p className="text-[7px] text-zinc-500 font-medium tracking-wider uppercase">Driver</p>
                        <p className="text-[9px] font-bold font-mono text-cyan-400 mt-0.5">
                          {isBitPerfect ? "BIT-PERFECT" : "MAPPED"}
                        </p>
                      </div>
                    </div>

                    {/* DAC Status Card */}
                    <div
                      onClick={() => setActiveTab("holocore")}
                      className="bg-gradient-to-br from-zinc-900/40 to-black/60 border border-white/5 p-4 rounded-[24px] cursor-pointer hover:border-cyan-500/30 transition-all shadow-lg backdrop-blur-xl mb-4 group"
                    >
                      <div className="flex justify-between items-center">
                        <span className="text-[8px] font-bold text-cyan-400 tracking-wider">HOLOCORE™ DAC STATUS</span>
                        <div className="flex items-center gap-1.5">
                          <span className="text-[7px] text-zinc-500 font-mono">VRMS: {((volume / 120) * 2.5).toFixed(2)}v</span>
                          <span className={`w-1.5 h-1.5 rounded-full ${isBitPerfect ? "bg-cyan-400 shadow-[0_0_6px_#00E5FF]" : "bg-amber-400"}`}></span>
                        </div>
                      </div>
                      <h4 className="text-sm font-semibold text-white mt-1.5 tracking-tight group-hover:text-cyan-400 transition-colors">
                        {isBitPerfect ? "HoloCore™ Reference DAC-X1" : "Qualcomm WCD9385 Core"}
                      </h4>
                      
                      <div className="grid grid-cols-2 gap-x-2 gap-y-1.5 mt-3 pt-3 border-t border-white/5 text-[9px]">
                        <div>
                          <span className="text-zinc-500 block uppercase tracking-wider">Audio Driver</span>
                          <span className="text-zinc-300 font-medium">{activeDriver}</span>
                        </div>
                        <div className="text-right">
                          <span className="text-zinc-500 block uppercase tracking-wider">Digital Filter</span>
                          <span className="text-zinc-300 font-medium">{activeFilter}</span>
                        </div>
                      </div>
                    </div>

                    {/* Current Song Controller Card */}
                    <div
                      className="bg-gradient-to-br from-zinc-900/60 to-black/80 border border-white/5 p-4 rounded-[32px] shadow-2xl relative overflow-hidden backdrop-blur-xl mb-4"
                    >
                      <div className="absolute -right-10 -bottom-10 w-24 h-24 bg-purple-600/5 rounded-full blur-2xl pointer-events-none" />
                      <div className="flex items-center gap-3" onClick={() => setActiveTab("music")}>
                        {/* Artwork placeholder */}
                        <div className={`w-12 h-12 rounded-xl bg-gradient-to-tr ${currentSong.coverColor} flex items-center justify-center border border-white/10 shrink-0`}>
                          <MusicIcon className="w-5 h-5 text-cyan-400/80" />
                        </div>
                        <div className="overflow-hidden flex-1 cursor-pointer">
                          <h4 className="text-xs font-bold text-white truncate">{currentSong.title}</h4>
                          <p className="text-[10px] text-zinc-400 truncate mt-0.5">{currentSong.artist} — {currentSong.album}</p>
                          <span className="text-[8px] text-cyan-400 bg-cyan-500/10 border border-cyan-500/30 px-1.5 py-0.5 rounded font-mono font-medium mt-1 inline-block shadow-[inset_0_0_12px_rgba(6,182,212,0.1)]">
                            {currentSong.kbps} kbps Lossless
                          </span>
                        </div>
                      </div>

                      {/* Dynamic Progress Indicator */}
                      <div className="mt-4">
                        <div className="relative w-full h-1 bg-zinc-800 rounded-full overflow-hidden">
                          <div
                            className="absolute top-0 left-0 h-full bg-gradient-to-r from-cyan-500 to-purple-500 shadow-[0_0_10px_rgba(34,211,238,0.5)]"
                            style={{ width: `${(progress / currentSong.durationSeconds) * 100}%` }}
                          />
                        </div>
                        <div className="flex justify-between items-center text-[8px] text-zinc-500 mt-1.5 font-mono">
                          <span>{formatTime(progress)}</span>
                          <span>{formatTime(currentSong.durationSeconds)}</span>
                        </div>
                      </div>

                      {/* Controls Buttons Row */}
                      <div className="flex items-center justify-center gap-5 mt-3">
                        <button
                          onClick={() => {
                            setCurrentSongIndex((prev) => (prev - 1 + trackList.length) % trackList.length);
                            setProgress(0);
                          }}
                          className="p-2 text-zinc-500 hover:text-white transition-colors cursor-pointer"
                        >
                          <SkipBack className="w-4 h-4" />
                        </button>
                        
                        <button
                          onClick={() => setIsPlaying(!isPlaying)}
                          className="w-10 h-10 rounded-full bg-zinc-900/40 border border-white/10 text-white flex items-center justify-center shadow-md hover:bg-zinc-800/60 active:scale-95 transition-all cursor-pointer"
                        >
                          {isPlaying ? <Pause className="w-4 h-4 fill-white" /> : <Play className="w-4 h-4 fill-white ml-0.5" />}
                        </button>

                        <button
                          onClick={() => {
                            setCurrentSongIndex((prev) => (prev + 1) % trackList.length);
                            setProgress(0);
                          }}
                          className="p-2 text-zinc-500 hover:text-white transition-colors cursor-pointer"
                        >
                          <SkipForward className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {/* Centered Premium Footer */}
                    <div className="text-center py-2 mt-auto">
                      <p className="text-[8px] font-bold text-zinc-600 tracking-[0.25em] uppercase">Developed by Chrissy Godwin</p>
                    </div>
                  </div>
                )}

                {/* 3. MUSIC LIBRARY TAB */}
                {activeTab === "music" && (
                  <div className="flex-1 p-5 flex flex-col justify-between animate-fade-in">
                    <div>
                      <h3 className="text-lg font-light text-white tracking-wide">Hi-Res Library</h3>
                      <p className="text-[8px] font-bold text-cyan-400 tracking-wider">DIRECT HARDWARE STORAGE INTERFACE</p>

                      <div className="mt-5 space-y-3">
                        {trackList.map((song, idx) => {
                          const isCurrent = idx === currentSongIndex;
                          return (
                            <div
                              key={song.id}
                              onClick={() => {
                                setCurrentSongIndex(idx);
                                setProgress(0);
                                setIsPlaying(true);
                              }}
                              className={`p-3 rounded-xl border transition-all cursor-pointer flex items-center gap-3 ${
                                isCurrent
                                  ? "bg-cyan-500/5 border-cyan-500/30 text-white shadow-[inset_0_0_12px_rgba(6,182,212,0.05)]"
                                  : "bg-zinc-900/40 border-white/5 hover:bg-zinc-800/40"
                              }`}
                            >
                              <div className={`w-9 h-9 rounded-lg bg-gradient-to-tr ${song.coverColor} flex items-center justify-center border border-white/5`}>
                                <MusicIcon className={`w-4 h-4 ${isCurrent ? "text-cyan-400" : "text-zinc-500"}`} />
                              </div>
                              <div className="flex-1 overflow-hidden">
                                <h4 className={`text-xs font-semibold truncate ${isCurrent ? "text-cyan-400" : "text-zinc-200"}`}>{song.title}</h4>
                                <p className="text-[9px] text-zinc-500 truncate mt-0.5">{song.artist}</p>
                              </div>
                              <div className="text-right shrink-0">
                                <span className="text-[9px] font-mono font-medium text-zinc-300 block">{song.fileFormat}</span>
                                <span className="text-[8px] font-mono text-zinc-500 block">
                                  {song.fileFormat === "DSD" ? "DSD64" : `${song.sampleRateHz / 1000}kHz`}
                                </span>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                    <div className="text-center py-2 mt-auto">
                      <p className="text-[8px] font-bold text-zinc-600 tracking-[0.25em] uppercase">Developed by Chrissy Godwin</p>
                    </div>
                  </div>
                )}

                {/* 4. HOLOCORE CONTROL SCREEN */}
                {activeTab === "holocore" && (
                  <div className="flex-1 p-5 flex flex-col justify-between animate-fade-in">
                    <div>
                      <h3 className="text-lg font-light text-white tracking-wide">HoloCore™ Engine</h3>
                      <p className="text-[8px] font-bold text-cyan-400 tracking-wider">DSP & DRIVER DIRECT HARDWARE MATRIX</p>

                      {/* Bit-Perfect Switch */}
                      <div className="mt-5 p-4 bg-zinc-900/40 border border-white/5 rounded-2xl flex items-center justify-between backdrop-blur-xl">
                        <div>
                          <h4 className="text-xs font-semibold text-white">Bit-Perfect Mode</h4>
                          <p className="text-[9px] text-zinc-500 mt-0.5">Bypasses the Android OS audio mixer stack</p>
                        </div>
                        <button
                          onClick={() => {
                            setIsBitPerfect(!isBitPerfect);
                            setActiveDriver(!isBitPerfect ? "HoloCore™ Bit-Perfect USB" : "Standard (AAudio)");
                          }}
                          className={`w-10 h-5 rounded-full transition-all relative ${isBitPerfect ? "bg-cyan-500" : "bg-zinc-800"}`}
                        >
                          <div
                            className={`w-4 h-4 rounded-full bg-black absolute top-0.5 transition-all ${
                              isBitPerfect ? "left-5.5" : "left-0.5"
                            }`}
                          />
                        </button>
                      </div>

                      {/* Driver Selection */}
                      <div className="mt-4">
                        <span className="text-[8px] font-bold text-zinc-600 tracking-wider uppercase block mb-2">Select Audio Driver</span>
                        <div className="space-y-1.5">
                          {["HoloCore™ Bit-Perfect USB", "Standard (AAudio)", "HoloCore™ Native DSD Direct"].map((driver) => {
                            const selected = activeDriver === driver;
                            return (
                              <div
                                key={driver}
                                onClick={() => {
                                  setActiveDriver(driver);
                                  setIsBitPerfect(driver.includes("Bit-Perfect") || driver.includes("DSD Direct"));
                                }}
                                className={`p-2.5 rounded-xl text-xs font-medium border cursor-pointer transition-all flex justify-between items-center ${
                                  selected
                                    ? "bg-zinc-900/60 border-cyan-500/30 text-white"
                                    : "bg-zinc-950/20 border-white/5 text-zinc-500 hover:bg-zinc-900/20"
                                }`}
                              >
                                <span>{driver}</span>
                                {selected && <div className="w-1.5 h-1.5 rounded-full bg-cyan-400" />}
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      {/* DAC Reconstruction Filters */}
                      <div className="mt-4">
                        <span className="text-[8px] font-bold text-zinc-600 tracking-wider uppercase block mb-2">DAC Anti-Aliasing Filters</span>
                        <div className="space-y-1.5">
                          {["Minimum Phase (Fast)", "Apodizing Fast Roll-Off", "Slow Roll-Off (Linear)", "Hybrid Fast Roll-Off"].map((filter) => {
                            const selected = activeFilter === filter;
                            return (
                              <div
                                key={filter}
                                onClick={() => setActiveFilter(filter)}
                                className={`p-2.5 rounded-xl text-xs font-medium border cursor-pointer transition-all flex justify-between items-center ${
                                  selected
                                    ? "bg-zinc-900/60 border-cyan-500/30 text-white"
                                    : "bg-zinc-950/20 border-white/5 text-zinc-500 hover:bg-zinc-900/20"
                                }`}
                              >
                                <span>{filter}</span>
                                {selected && <div className="w-1.5 h-1.5 rounded-full bg-cyan-400" />}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                    <div className="text-center py-2 mt-auto">
                      <p className="text-[8px] font-bold text-zinc-600 tracking-[0.25em] uppercase">Developed by Chrissy Godwin</p>
                    </div>
                  </div>
                )}

                {/* 5. EQ TAB */}
                {activeTab === "eq" && (
                  <div className="flex-1 p-5 flex flex-col justify-between animate-fade-in">
                    <div>
                      <h3 className="text-lg font-light text-white tracking-wide">Parametric EQ</h3>
                      <p className="text-[8px] font-bold text-cyan-400 tracking-wider">64-BIT DOUBLE PRECISION FLOATING EQUALIZER</p>

                      {/* Graphic EQ Visual Curve */}
                      <div className="mt-4 h-32 rounded-xl bg-zinc-950/40 border border-white/5 relative flex items-end justify-between p-3 overflow-hidden">
                        {/* Curve backdrop */}
                        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom,rgba(142,36,170,0.1),transparent)] pointer-events-none" />
                        <svg className="absolute inset-0 w-full h-full pointer-events-none stroke-cyan-400/40 fill-transparent" viewBox="0 0 300 100">
                          <path d="M 0 50 Q 75 30 150 60 T 300 40" strokeWidth="1.5" />
                        </svg>

                        {/* Slider bar columns */}
                        {[30, 42, 60, 50, 35, 45, 58, 62, 40, 48].map((val, idx) => (
                          <div key={idx} className="w-2.5 bg-zinc-900/40 h-24 rounded-full flex flex-col justify-end items-center">
                            <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 shadow-[0_0_6px_#00E5FF] mb-1" style={{ transform: `translateY(-${val / 1.5}px)` }} />
                            <div className="w-0.5 bg-cyan-400/20 rounded-full flex-1" />
                          </div>
                        ))}
                      </div>

                      <div className="mt-5 space-y-3.5">
                        <span className="text-[8px] font-bold text-zinc-500 tracking-wider uppercase block">Analog Presets</span>
                        <div className="grid grid-cols-3 gap-2">
                          {["Reference", "Gold Valve", "Pure Tube", "Solid State", "Acoustic", "Studio"].map((preset) => (
                            <div
                              key={preset}
                              className={`p-2 text-[10px] text-center font-medium rounded-lg border ${
                                preset === "Reference"
                                  ? "bg-zinc-900/60 border-cyan-500/30 text-cyan-400"
                                  : "bg-zinc-950/20 border-white/5 text-zinc-500 hover:bg-zinc-900/40"
                              } cursor-pointer`}
                            >
                              {preset}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                    <div className="text-center py-2 mt-auto">
                      <p className="text-[8px] font-bold text-zinc-600 tracking-[0.25em] uppercase">Developed by Chrissy Godwin</p>
                    </div>
                  </div>
                )}

                {/* 6. ANALYZER TAB */}
                {activeTab === "analyzer" && (
                  <div className="flex-1 p-5 flex flex-col justify-between animate-fade-in h-full">
                    <div className="flex-1 flex flex-col h-full">
                      <h3 className="text-lg font-light text-white tracking-wide">FFT Spectrum</h3>
                      <p className="text-[8px] font-bold text-cyan-400 tracking-wider">OCTAVE-BAND SPECTRUM REALTIME FFT ANALYZER</p>

                      {/* Spectrum visualizer canvas */}
                      <div className="mt-4 flex-1 min-h-[180px] rounded-2xl bg-zinc-950 border border-white/5 flex flex-col p-4 relative overflow-hidden shadow-inner">
                        <canvas ref={analyzerCanvasRef} className="w-full flex-1 rounded-lg" />
                        <div className="flex justify-between items-center text-[8px] text-zinc-600 font-mono mt-2 pt-2 border-t border-white/5">
                          <span>31Hz</span>
                          <span>250Hz</span>
                          <span>1kHz</span>
                          <span>4kHz</span>
                          <span>16kHz</span>
                        </div>
                      </div>
                    </div>
                    <div className="text-center py-2 mt-4 shrink-0">
                      <p className="text-[8px] font-bold text-zinc-600 tracking-[0.25em] uppercase">Developed by Chrissy Godwin</p>
                    </div>
                  </div>
                )}

                {/* 7. SETTINGS TAB */}
                {activeTab === "settings" && (
                  <div className="flex-1 p-5 flex flex-col justify-between animate-fade-in">
                    <div>
                      <h3 className="text-lg font-light text-white tracking-wide">Settings</h3>
                      <p className="text-[8px] font-bold text-cyan-400 tracking-wider">HOLOCORE™ SYSTEM ARCHITECTURE CONTROLS</p>

                      {/* Tuning Toggles */}
                      <div className="mt-5 space-y-2">
                        <span className="text-[8px] font-bold text-zinc-600 tracking-wider uppercase block mb-1">Hardware Options</span>
                        
                        <div className="p-3 bg-zinc-900/40 border border-white/5 rounded-xl flex items-center justify-between">
                          <div>
                            <h4 className="text-xs font-semibold text-white">Hardware MQA Rendering</h4>
                            <p className="text-[9px] text-zinc-500">Enables dual hardware fold decoding</p>
                          </div>
                          <div className="w-7 h-4 bg-cyan-400 rounded-full" />
                        </div>

                        <div className="p-3 bg-zinc-900/40 border border-white/5 rounded-xl flex items-center justify-between">
                          <div>
                            <h4 className="text-xs font-semibold text-white">DSD Over PCM (DoP)</h4>
                            <p className="text-[9px] text-zinc-500">Encapsulates native DSD inside PCM</p>
                          </div>
                          <div className="w-7 h-4 bg-zinc-800 rounded-full" />
                        </div>

                        <div className="p-3 bg-zinc-900/40 border border-white/5 rounded-xl flex items-center justify-between">
                          <div>
                            <h4 className="text-xs font-semibold text-white">Exclusive USB Mode</h4>
                            <p className="text-[9px] text-zinc-500">Takes absolute hardware monopoly</p>
                          </div>
                          <div className="w-7 h-4 bg-cyan-400 rounded-full" />
                        </div>
                      </div>

                      {/* About Pipeline details */}
                      <div className="mt-5 p-4 bg-zinc-950/40 border border-white/5 rounded-xl space-y-2">
                        <span className="text-[8px] font-bold text-zinc-600 tracking-wider uppercase block mb-1">About Architecture</span>
                        <div className="flex justify-between text-[10px]"><span className="text-zinc-500">Application Name</span><span className="text-white font-medium">AuraWaveX</span></div>
                        <div className="flex justify-between text-[10px]"><span className="text-zinc-500">Lead Architect</span><span className="text-white font-medium">Chrissy Godwin</span></div>
                        <div className="flex justify-between text-[10px]"><span className="text-zinc-500">Audio Engine</span><span className="text-cyan-400 font-mono">HoloCore™ v4.2-Pro</span></div>
                        <div className="flex justify-between text-[10px]"><span className="text-zinc-500">UI Layout Framework</span><span className="text-white font-medium">Jetpack Compose</span></div>
                      </div>
                    </div>
                    <div className="text-center py-2 mt-auto">
                      <p className="text-[8px] font-bold text-zinc-600 tracking-[0.25em] uppercase">Developed by Chrissy Godwin</p>
                    </div>
                  </div>
                )}

              </div>

              {/* BOTTOM NAVIGATION BAR */}
              {activeTab !== "splash" && (
                <div className="border-t border-white/5 bg-zinc-950/80 backdrop-blur-md px-1 py-1 flex items-center justify-around z-40 shrink-0">
                  {[
                    { tab: "home", label: "Home" },
                    { tab: "music", label: "Music" },
                    { tab: "holocore", label: "HoloCore" },
                    { tab: "eq", label: "EQ" },
                    { tab: "analyzer", label: "Analyzer" },
                    { tab: "settings", label: "Settings" }
                  ].map((item) => {
                    const selected = activeTab === item.tab;
                    return (
                      <button
                        key={item.tab}
                        onClick={() => setActiveTab(item.tab)}
                        className="flex flex-col items-center py-1 px-1.5 transition-all hover:text-cyan-400 cursor-pointer"
                      >
                        <div className={`w-1.5 h-1.5 rounded-full mb-1 transition-all ${selected ? "bg-cyan-400 scale-125" : "bg-zinc-700"}`} />
                        <span className={`text-[8px] tracking-tight font-medium ${selected ? "text-cyan-400 font-semibold" : "text-zinc-500"}`}>
                          {item.label}
                        </span>
                      </button>
                    );
                  })}
                </div>
              )}

              {/* Android Home Navigation Gesture Bar */}
              {activeTab !== "splash" && (
                <div className="bg-black py-1.5 flex justify-center items-center z-40 shrink-0">
                  <div className="w-24 h-1 bg-zinc-800 rounded-full"></div>
                </div>
              )}

            </div>
          </div>

          {/* Simulated hardware volume dial slider */}
          {activeTab !== "splash" && (
            <div className="w-full max-w-[340px] mt-5 bg-zinc-900/40 border border-white/5 rounded-2xl p-4 backdrop-blur-md flex items-center gap-4">
              <Volume2 className="w-5 h-5 text-cyan-400 shrink-0" />
              <div className="flex-1">
                <div className="flex justify-between items-center text-[10px] text-zinc-500 mb-1.5 font-mono">
                  <span>Hardware Vol Coarse</span>
                  <span className="text-cyan-400 font-bold">{volume} / 120 Steps</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="120"
                  value={volume}
                  onChange={(e) => setVolume(Number(e.target.value))}
                  className="w-full accent-cyan-400 bg-zinc-800 h-1 rounded-lg cursor-pointer"
                />
              </div>
            </div>
          )}

        </div>

        {/* RIGHT COLUMN: Interactive Jetpack Compose Project & Code Inspector (lg:col-span-7) */}
        <div id="project-files" className="lg:col-span-7 flex flex-col h-full bg-zinc-950/40 border border-white/5 rounded-3xl overflow-hidden shadow-2xl backdrop-blur-md">
          
          {/* Studio IDE Header Tab */}
          <div className="bg-zinc-950/80 border-b border-white/5 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shrink-0">
            <div className="flex items-center gap-2">
              <div className="flex gap-1.5 mr-2">
                <span className="w-3 h-3 rounded-full bg-red-500/20 border border-red-500/40"></span>
                <span className="w-3 h-3 rounded-full bg-yellow-500/20 border border-yellow-500/40"></span>
                <span className="w-3 h-3 rounded-full bg-green-500/20 border border-green-500/40"></span>
              </div>
              <span className="text-zinc-400 text-xs font-mono">Android Studio Project Explorer</span>
            </div>
            
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-zinc-500 font-mono">targetSdk 34 (Android 14)</span>
              <span className="text-zinc-700">|</span>
              <span className="text-[10px] text-cyan-400 font-bold tracking-wider">HOLOCORE™ ACTIVE DEPLOY</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 flex-1 divide-y md:divide-y-0 md:divide-x divide-white/5">
            
            {/* File explorer Sidebar (md:col-span-5) */}
            <div className="md:col-span-5 p-4 bg-zinc-950/20 overflow-y-auto max-h-[500px] md:max-h-[640px]">
              <span className="text-[9px] font-bold text-zinc-500 tracking-widest uppercase block mb-3">Project Folders</span>
              {renderTree(sourceProject)}
            </div>

            {/* Code viewer Screen (md:col-span-7) */}
            <div className="md:col-span-7 flex flex-col bg-zinc-950/40 max-h-[500px] md:max-h-[640px]">
              {selectedFile ? (
                <>
                  {/* File status title bar */}
                  <div className="border-b border-white/5 bg-zinc-900/30 px-4 py-2.5 flex items-center justify-between">
                    <div className="flex items-center gap-2 overflow-hidden">
                      <FileCode className="w-4 h-4 text-cyan-400 shrink-0" />
                      <span className="font-mono text-xs text-zinc-200 truncate">{selectedFile.name}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={handleCopyCode}
                        className="p-1.5 rounded bg-zinc-900/60 hover:bg-zinc-800/60 border border-white/5 text-zinc-300 hover:text-white transition-all flex items-center gap-1.5 text-[10px] font-semibold cursor-pointer"
                        title="Copy to clipboard"
                      >
                        {copiedFile ? (
                          <>
                            <Check className="w-3 h-3 text-cyan-400" />
                            <span className="text-cyan-400 font-bold">Copied</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3 h-3" />
                            <span>Copy</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Highlighted text container */}
                  <div className="flex-1 p-4 overflow-y-auto font-mono text-xs leading-relaxed text-zinc-300 relative bg-black">
                    <pre className="overflow-x-auto selection:bg-cyan-500/20 whitespace-pre-wrap sm:whitespace-pre">
                      <code className="block">
                        {selectedFile.content.split("\n").map((line, i) => (
                          <div key={i} className="table-row">
                            <span className="table-cell text-zinc-700 text-right pr-4 select-none text-[10px] w-6">
                              {i + 1}
                            </span>
                            <span className="table-cell whitespace-pre">{line}</span>
                          </div>
                        ))}
                      </code>
                    </pre>
                  </div>
                </>
              ) : (
                <div className="flex-1 flex flex-col items-center justify-center p-8 text-center text-zinc-500">
                  <AlertCircle className="w-8 h-8 text-zinc-600 mb-2" />
                  <p className="text-xs">Select a file from the explorer on the left to inspect its production Kotlin / Compose code.</p>
                </div>
              )}

            </div>
          </div>

          {/* Android Studio console console log bar */}
          <div className="border-t border-white/5 bg-zinc-950/80 p-4 shrink-0">
            <span className="text-[9px] font-bold text-zinc-500 tracking-widest uppercase block mb-1.5">Compilation Output log</span>
            <div className="font-mono text-[10px] text-cyan-400/90 leading-tight space-y-1 bg-black/40 border border-white/5 p-3 rounded-lg">
              <div>&gt; task :app:compileDebugKotlin <span className="text-zinc-500">... SUCCESS</span></div>
              <div>&gt; task :app:transformClassesWithDexBuilderForDebug <span className="text-zinc-500">... SUCCESS</span></div>
              <div>&gt; task :app:packageDebug <span className="text-zinc-500">... SUCCESS</span></div>
              <div className="text-white">&gt; Build Finished: <span className="text-cyan-400 font-bold">Successfully compiled AuraWaveX application module matching 100% senior architectures!</span></div>
            </div>
          </div>

        </div>

      </main>

      {/* Flagship Product Showcase Cards */}
      <section className="bg-zinc-950/20 border-t border-white/5 py-10 px-6 mt-12 shrink-0 relative z-10">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-lg font-bold text-white mb-6 tracking-tight flex items-center gap-2">
            <Info className="w-4 h-4 text-cyan-400" />
            AuraWaveX Architecture Specifications
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-zinc-900/10 border border-white/5 p-5 rounded-2xl backdrop-blur-xl">
              <h3 className="text-xs font-bold text-cyan-400 tracking-wider uppercase mb-2">Clean MVVM Architecture</h3>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Decoupled architecture separation separating core data entities, simulated drivers, and Jetpack Compose composables via structured Kotlin Flow view models. Allows plugging in hardware layers with ease.
              </p>
            </div>
            <div className="bg-zinc-900/10 border border-white/5 p-5 rounded-2xl backdrop-blur-xl">
              <h3 className="text-xs font-bold text-cyan-400 tracking-wider uppercase mb-2">AMOLED Glassmorphism</h3>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Bespoke design utilizing pure dark backdrops, subtle blurred translucency dividers, electric status indicators, and balanced micro-typography scales ready for modern 120Hz/144Hz displays.
              </p>
            </div>
            <div className="bg-zinc-900/10 border border-white/5 p-5 rounded-2xl backdrop-blur-xl">
              <h3 className="text-xs font-bold text-cyan-400 tracking-wider uppercase mb-2">HoloCore™ Audio Engine</h3>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Engineered path for Android high-performance AAudio and direct hardware USB accessory API drivers to completely override standard kernel resamplers and execute bit-perfect conversions.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Developer credit line */}
      <footer className="border-t border-white/5 bg-zinc-950/40 text-center py-6 text-zinc-500 text-xs shrink-0 relative z-10">
        <div className="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p>© 2026 AuraWaveX. Powered by HoloCore™ Audio Engine.</p>
          <p>Created by <span className="text-zinc-300 font-semibold">Chrissy Godwin</span>, Senior Android & Audio Architect.</p>
        </div>
      </footer>
    </div>
  );
}
