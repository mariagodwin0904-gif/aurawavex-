export interface SourceFile {
  name: string;
  path: string;
  content: string;
}

export interface SourceDir {
  name: string;
  files: SourceFile[];
  subdirs?: SourceDir[];
}

export const sourceProject: SourceDir = {
  name: "AuraWaveX Project",
  files: [],
  subdirs: [
    {
      name: "app",
      files: [],
      subdirs: [
        {
          name: "manifests",
          files: [
            {
              name: "AndroidManifest.xml",
              path: "app/src/main/AndroidManifest.xml",
              content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.aurawavex.app">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="AuraWaveX"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.AuraWaveX">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:theme="@style/Theme.AuraWaveX.Splash">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`
            }
          ]
        },
        {
          name: "java/com/aurawavex/app",
          files: [
            {
              name: "MainActivity.kt",
              path: "app/src/main/java/com/aurawavex/app/MainActivity.kt",
              content: `package com.aurawavex.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.core.view.WindowCompat
import com.aurawavex.app.ui.theme.AuraWaveXTheme
import com.aurawavex.app.navigation.AuraWaveXNavigation
import com.aurawavex.app.viewmodel.AudioViewModel
import com.aurawavex.app.viewmodel.DacViewModel

/**
 * MainActivity
 * Entry point for AuraWaveX.
 * Configures edge-to-edge rendering, initializes core view models, and bootstraps the AuraWaveX navigation graph.
 * 
 * Powered by HoloCore™
 * Developed by Chrissy Godwin
 */
class MainActivity : ComponentActivity() {
    
    private val audioViewModel: AudioViewModel by viewModels()
    private val dacViewModel: DacViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Enable edge-to-edge system bars integration
        WindowCompat.setDecorFitsSystemWindows(window, false)

        setContent {
            AuraWaveXTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AuraWaveXNavigation(
                        audioViewModel = audioViewModel,
                        dacViewModel = dacViewModel
                    )
                }
            }
        }
    }
}`
            }
          ],
          subdirs: [
            {
              name: "model",
              files: [
                {
                  name: "Song.kt",
                  path: "app/src/main/java/com/aurawavex/app/model/Song.kt",
                  content: `package com.aurawavex.app.model

/**
 * Song
 * Represents a high-resolution audiophile track.
 * Powered by HoloCore™
 */
data class Song(
    val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val durationSeconds: Int,
    val sampleRateHz: Int,
    val bitDepth: Int,
    val fileFormat: String, // FLAC, DSD, WAV, MQA
    val kbps: Int,
    val isHiRes: Boolean = true,
    val coverArtPlaceholderHex: String = "#0D0D12"
) {
    val displaySampleRate: String
        get() = if (fileFormat == "DSD") {
            "DSD\${sampleRateHz / 44100}"
        } else {
            "\${sampleRateHz / 1000.0} kHz"
        }

    val displayBitDepth: String
        get() = if (fileFormat == "DSD") "1-bit" else "\$bitDepth-bit"
}`
                },
                {
                  name: "DacState.kt",
                  path: "app/src/main/java/com/aurawavex/app/model/DacState.kt",
                  content: `package com.aurawavex.app.model

/**
 * DacConnectionStatus
 */
enum class DacConnectionStatus {
    DISCONNECTED,
    CONNECTING,
    CONNECTED_INTERNAL,
    CONNECTED_USB
}

/**
 * DacFilter
 */
enum class DacFilter(val displayName: String) {
    FAST_ROLL_OFF("Fast Roll-Off (Linear)"),
    SLOW_ROLL_OFF("Slow Roll-Off (Linear)"),
    MINIMUM_PHASE("Minimum Phase (Fast)"),
    APODIZING("Apodizing Fast Roll-Off"),
    HYBRID_FAST("Hybrid Fast Roll-Off")
}

/**
 * AudioDriver
 */
enum class AudioDriver(val displayName: String) {
    STANDARD("Standard (AAudio)"),
    BIT_PERFECT_USB("HoloCore™ Bit-Perfect USB"),
    DIRECT_DSD("HoloCore™ Native DSD Direct")
}

/**
 * DacState
 * Holds real-time stats of the current digital-to-analog converter hardware.
 * Powered by HoloCore™
 */
data class DacState(
    val status: DacConnectionStatus = DacConnectionStatus.CONNECTED_USB,
    val modelName: String = "HoloCore™ Reference DAC-X1",
    val driver: AudioDriver = AudioDriver.BIT_PERFECT_USB,
    val filter: DacFilter = DacFilter.MINIMUM_PHASE,
    val sampleRateHz: Int = 192000,
    val bitDepth: Int = 24,
    val isBitPerfect: Boolean = true,
    val mqaStatus: String = "MQA Studio Decoder",
    val voltageVrms: Double = 2.2,
    val volumeStep: Int = 85,
    val maxVolumeSteps: Int = 120
)`
                }
              ]
            },
            {
              name: "viewmodel",
              files: [
                {
                  name: "AudioViewModel.kt",
                  path: "app/src/main/java/com/aurawavex/app/viewmodel/AudioViewModel.kt",
                  content: `package com.aurawavex.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aurawavex.app.model.Song
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * AudioViewModel
 * Manages the high-resolution audiophile audio track queue and simulated audio playback.
 * Powered by HoloCore™
 */
class AudioViewModel : ViewModel() {

    private val trackList = listOf(
        Song(
            id = "track_1",
            title = "Aether Waves",
            artist = "Luminance Duo",
            album = "Quantum Echoes",
            durationSeconds = 342,
            sampleRateHz = 192000,
            bitDepth = 24,
            fileFormat = "FLAC",
            kbps = 5820,
            coverArtPlaceholderHex = "#0C1424"
        ),
        Song(
            id = "track_2",
            title = "Nebula Dreams",
            artist = "Cosmic Synthesis",
            album = "Stellar Audio Experience",
            durationSeconds = 485,
            sampleRateHz = 352800,
            bitDepth = 32,
            fileFormat = "WAV",
            kbps = 9216,
            coverArtPlaceholderHex = "#160C24"
        ),
        Song(
            id = "track_3",
            title = "Absolute Horizon (Master Edition)",
            artist = "Vortex Field",
            album = "HoloCore Showcase Vol. I",
            durationSeconds = 294,
            sampleRateHz = 2822400, // DSD64
            bitDepth = 1,
            fileFormat = "DSD",
            kbps = 5644,
            coverArtPlaceholderHex = "#0D1E16"
        )
    )

    private val _currentSong = MutableStateFlow(trackList[0])
    val currentSong: StateFlow<Song> = _currentSong.asStateFlow()

    private val _isPlaying = MutableStateFlow(true)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentProgressSeconds = MutableStateFlow(42)
    val currentProgressSeconds: StateFlow<Int> = _currentProgressSeconds.asStateFlow()

    private var playbackJob: Job? = null

    init {
        startProgressSim()
    }

    private fun startProgressSim() {
        playbackJob?.cancel()
        playbackJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                if (_isPlaying.value) {
                    val nextSec = _currentProgressSeconds.value + 1
                    if (nextSec >= _currentSong.value.durationSeconds) {
                        nextTrack()
                    } else {
                        _currentProgressSeconds.value = nextSec
                    }
                }
            }
        }
    }

    fun togglePlayPause() {
        _isPlaying.value = !_isPlaying.value
    }

    fun nextTrack() {
        val currentIndex = trackList.indexOf(_currentSong.value)
        val nextIndex = (currentIndex + 1) % trackList.size
        _currentSong.value = trackList[nextIndex]
        _currentProgressSeconds.value = 0
    }

    fun prevTrack() {
        val currentIndex = trackList.indexOf(_currentSong.value)
        var prevIndex = currentIndex - 1
        if (prevIndex < 0) prevIndex = trackList.size - 1
        _currentSong.value = trackList[prevIndex]
        _currentProgressSeconds.value = 0
    }

    fun getSongs(): List<Song> = trackList

    fun selectSong(song: Song) {
        _currentSong.value = song
        _currentProgressSeconds.value = 0
        _isPlaying.value = true
    }

    override fun onCleared() {
        super.onCleared()
        playbackJob?.cancel()
    }
}`
                },
                {
                  name: "DacViewModel.kt",
                  path: "app/src/main/java/com/aurawavex/app/viewmodel/DacViewModel.kt",
                  content: `package com.aurawavex.app.viewmodel

import androidx.lifecycle.ViewModel
import com.aurawavex.app.model.AudioDriver
import com.aurawavex.app.model.DacConnectionStatus
import com.aurawavex.app.model.DacFilter
import com.aurawavex.app.model.DacState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * DacViewModel
 * Manages configuration, voltage scaling, bit-perfect routing, and digital filter selection of the DAC.
 * Powered by HoloCore™
 */
class DacViewModel : ViewModel() {

    private val _dacState = MutableStateFlow(DacState())
    val dacState: StateFlow<DacState> = _dacState.asStateFlow()

    fun setDacConnection(status: DacConnectionStatus) {
        _dacState.update { current ->
            current.copy(
                status = status,
                modelName = when (status) {
                    DacConnectionStatus.DISCONNECTED -> "No Audio Hardware Detected"
                    DacConnectionStatus.CONNECTING -> "Handshaking..."
                    DacConnectionStatus.CONNECTED_INTERNAL -> "Qualcomm WCD9385 Built-in DAC"
                    DacConnectionStatus.CONNECTED_USB -> "HoloCore™ Reference DAC-X1"
                }
            )
        }
    }

    fun setAudioDriver(driver: AudioDriver) {
        _dacState.update { current ->
            current.copy(
                driver = driver,
                isBitPerfect = driver == AudioDriver.BIT_PERFECT_USB || driver == AudioDriver.DIRECT_DSD
            )
        }
    }

    fun setDacFilter(filter: DacFilter) {
        _dacState.update { it.copy(filter = filter) }
    }

    fun updateVolume(step: Int) {
        _dacState.update { current ->
            val cleanStep = step.coerceIn(0, current.maxVolumeSteps)
            current.copy(
                volumeStep = cleanStep,
                voltageVrms = (cleanStep.toDouble() / current.maxVolumeSteps) * 2.5
            )
        }
    }

    fun toggleBitPerfect() {
        _dacState.update { current ->
            val nextBp = !current.isBitPerfect
            val driver = if (nextBp) AudioDriver.BIT_PERFECT_USB else AudioDriver.STANDARD
            current.copy(
                isBitPerfect = nextBp,
                driver = driver
            )
        }
    }
}`
                }
              ]
            },
            {
              name: "ui",
              files: [],
              subdirs: [
                {
                  name: "theme",
                  files: [
                    {
                      name: "Color.kt",
                      path: "app/src/main/java/com/aurawavex/app/ui/theme/Color.kt",
                      content: `package com.aurawavex.app.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * AuraWaveX Luxury Color Palette
 * Powered by HoloCore™
 */

// Pure AMOLED Black Canvas
val AmoledBlack = Color(0xFF000000)
val DarkGreyBg = Color(0xFF08080A)

// Luxury Accents
val ElectricBlue = Color(0xFF00E5FF)
val ElectricBlueGlow = Color(0x3300E5FF)
val DeepPurple = Color(0xFF8E24AA)
val DeepPurpleGlow = Color(0x338E24AA)

// Neutral Text & Icons
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xB3FFFFFF)
val TextMuted = Color(0x80FFFFFF)

// Glassmorphism System
val GlassBackground = Color(0x12FFFFFF)
val GlassBorder = Color(0x1AFFFFFF)
val GlassCardPressed = Color(0x26FFFFFF)

// Functional Statuses
val DacActiveGlow = Color(0xFF00E5FF)
val DacStandbyGlow = Color(0xFFFFB300)
val DacHiResColor = Color(0xFF00E5FF)
val DacMqaColor = Color(0xFFD500F9)
val DacBitPerfectColor = Color(0xFF00E676)`
                    },
                    {
                      name: "Type.kt",
                      path: "app/src/main/java/com/aurawavex/app/ui/theme/Type.kt",
                      content: `package com.aurawavex.app.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/**
 * AuraWaveX Typographic Scale
 * Built for 120Hz Displays and High-Density Audiophile Layouts.
 * Powered by HoloCore™
 */
val Typography = Typography(
    displayLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Light,
        fontSize = 57.sp,
        lineHeight = 64.sp,
        letterSpacing = (-0.25).sp,
        color = TextPrimary
    ),
    displayMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 45.sp,
        lineHeight = 52.sp,
        letterSpacing = 0.sp,
        color = TextPrimary
    ),
    headlineMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 28.sp,
        lineHeight = 36.sp,
        letterSpacing = 0.5.sp,
        color = TextPrimary
    ),
    titleLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 22.sp,
        lineHeight = 28.sp,
        letterSpacing = 0.sp,
        color = TextPrimary
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 16.sp,
        lineHeight = 24.sp,
        letterSpacing = 0.15.sp,
        color = TextPrimary
    ),
    bodyLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        lineHeight = 24.sp,
        letterSpacing = 0.5.sp,
        color = TextSecondary
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 20.sp,
        letterSpacing = 0.25.sp,
        color = TextSecondary
    ),
    labelLarge = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Medium,
        fontSize = 14.sp,
        lineHeight = 20.sp,
        letterSpacing = 0.1.sp,
        color = ElectricBlue
    ),
    labelSmall = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Normal,
        fontSize = 11.sp,
        lineHeight = 16.sp,
        letterSpacing = 0.5.sp,
        color = TextMuted
    )
)`
                    },
                    {
                      name: "Theme.kt",
                      path: "app/src/main/java/com/aurawavex/app/ui/theme/Theme.kt",
                      content: `package com.aurawavex.app.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = ElectricBlue,
    secondary = DeepPurple,
    tertiary = ElectricBlueGlow,
    background = AmoledBlack,
    surface = DarkGreyBg,
    onPrimary = AmoledBlack,
    onSecondary = TextPrimary,
    onBackground = TextPrimary,
    onSurface = TextSecondary
)

/**
 * AuraWaveXTheme
 * Luxury Pure AMOLED Black theme optimized for 120Hz Audiophile setups.
 * Powered by HoloCore™
 */
@Composable
fun AuraWaveXTheme(
    content: @Composable () -> Unit
) {
    val view = LocalView::current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = AmoledBlack.toArgb()
            window.navigationBarColor = AmoledBlack.toArgb()
            
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = false
            controller.isAppearanceLightNavigationBars = false
        }
    }

    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}`
                    }
                  ]
                },
                {
                  name: "screens",
                  files: [
                    {
                      name: "SplashScreen.kt",
                      path: "app/src/main/java/com/aurawavex/app/ui/screens/SplashScreen.kt",
                      content: `package com.aurawavex.app.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurawavex.app.ui.theme.ElectricBlue
import com.aurawavex.app.ui.theme.DeepPurple
import kotlinx.coroutines.delay
import kotlin.math.sin

/**
 * SplashScreen
 * Fades in a luxury dynamic logo that simulates wave particle motion.
 * Powered by HoloCore™
 */
@Composable
fun SplashScreen(onSplashCompleted: () -> Unit) {
    val scale = remember { Animatable(0.7f) }
    val alpha = remember { Animatable(0.0f) }
    val subtitleAlpha = remember { Animatable(0.0f) }

    val infiniteTransition = rememberInfiniteTransition(label = "wave_particles")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (Math.PI * 2).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ), label = "wave_phase"
    )

    LaunchedEffect(Unit) {
        scale.animateTo(1.0f, tween(1200, easing = EaseOutCubic))
        alpha.animateTo(1.0f, tween(1000))
        subtitleAlpha.animateTo(0.8f, tween(800, delayMillis = 600))
        
        delay(2500)
        onSplashCompleted()
    }

    Box(
        modifier = Modifier.fillMaxSize().background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(modifier = Modifier.size(160.dp).alpha(alpha.value), contentAlignment = Alignment.Center) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val radius = size.minDimension / 3f
                    val center = Offset(size.width / 2f, size.height / 2f)

                    for (i in 0 until 40) {
                        val angle = (i * Math.PI * 2 / 40).toFloat()
                        val waveOffset = sin(angle * 4 + phase) * 12f
                        val currentRadius = radius + waveOffset

                        val x = center.x + kotlin.math.cos(angle) * currentRadius
                        val y = center.y + sin(angle) * currentRadius

                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(ElectricBlue, Color.Transparent),
                                center = Offset(x, y),
                                radius = 10f
                            ),
                            radius = 6f,
                            center = Offset(x, y)
                        )
                    }

                    drawCircle(color = DeepPurple.copy(alpha = 0.3f), radius = radius - 8f, center = center)
                }
            }

            Spacer(modifier = Modifier.height(40.dp))

            Text(
                text = "AURAWA VEX",
                fontSize = 28.sp,
                letterSpacing = 12.sp,
                fontWeight = FontWeight.Light,
                color = Color.White
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "POWERED BY HOLOCORE™",
                fontSize = 11.sp,
                letterSpacing = 4.sp,
                fontWeight = FontWeight.Medium,
                color = ElectricBlue
            )
        }
    }
}`
                    },
                    {
                      name: "HomeScreen.kt",
                      path: "app/src/main/java/com/aurawavex/app/ui/screens/HomeScreen.kt",
                      content: `package com.aurawavex.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.aurawavex.app.navigation.Screen
import com.aurawavex.app.ui.theme.*
import com.aurawavex.app.viewmodel.AudioViewModel
import com.aurawavex.app.viewmodel.DacViewModel

/**
 * HomeScreen
 * The flagship hub of AuraWaveX.
 * Powered by HoloCore™
 */
@Composable
fun HomeScreen(
    navController: NavController,
    audioViewModel: AudioViewModel,
    dacViewModel: DacViewModel
) {
    val currentSong by audioViewModel.currentSong.collectAsState()
    val isPlaying by audioViewModel.isPlaying.collectAsState()
    val currentProgress by audioViewModel.currentProgressSeconds.collectAsState()
    val dacState by dacViewModel.dacState.collectAsState()

    val scrollState = rememberScrollState()

    Scaffold(
        bottomBar = {
            AuraWaveXBottomBar(
                currentRoute = Screen.Home.route,
                onNavigate = { route ->
                    if (route != Screen.Home.route) {
                        navController.navigate(route) { launchSingleTop = true }
                    }
                }
            )
        },
        containerColor = AmoledBlack
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(AmoledBlack)
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            HeaderBranding()

            Spacer(modifier = Modifier.height(24.dp))

            InteractiveWaveformContainer(isPlaying = isPlaying)

            Spacer(modifier = Modifier.height(24.dp))

            DacIndicatorsRow(
                sampleRate = currentSong.displaySampleRate,
                bitDepth = currentSong.displayBitDepth,
                format = currentSong.fileFormat,
                isBitPerfect = dacState.isBitPerfect
            )

            Spacer(modifier = Modifier.height(20.dp))

            DacStatusCard(
                modelName = dacState.modelName,
                driverName = dacState.driver.displayName,
                filterName = dacState.filter.displayName,
                voltage = dacState.voltageVrms,
                volumeStep = dacState.volumeStep,
                mqaStatus = dacState.mqaStatus,
                isBitPerfect = dacState.isBitPerfect,
                onClick = { navController.navigate(Screen.HoloCore.route) }
            )

            Spacer(modifier = Modifier.height(20.dp))

            CurrentSongCard(
                title = currentSong.title,
                artist = currentSong.artist,
                album = currentSong.album,
                progress = currentProgress,
                duration = currentSong.durationSeconds,
                isPlaying = isPlaying,
                kbps = currentSong.kbps,
                coverHex = currentSong.coverArtPlaceholderHex,
                onPlayPauseToggle = { audioViewModel.togglePlayPause() },
                onNextTrack = { audioViewModel.nextTrack() },
                onPrevTrack = { audioViewModel.prevTrack() },
                onClick = { navController.navigate(Screen.Music.route) }
            )

            Spacer(modifier = Modifier.height(32.dp))

            DevelopedByFooter()

            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}`
                    },
                    {
                      name: "HoloCoreScreen.kt",
                      path: "app/src/main/java/com/aurawavex/app/ui/screens/HoloCoreScreen.kt",
                      content: `package com.aurawavex.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.aurawavex.app.model.AudioDriver
import com.aurawavex.app.model.DacFilter
import com.aurawavex.app.navigation.Screen
import com.aurawavex.app.ui.theme.*
import com.aurawavex.app.viewmodel.DacViewModel

@Composable
fun HoloCoreScreen(
    navController: NavController,
    dacViewModel: DacViewModel
) {
    val dacState by dacViewModel.dacState.collectAsState()
    val scrollState = rememberScrollState()

    Scaffold(
        bottomBar = {
            AuraWaveXBottomBar(
                currentRoute = Screen.HoloCore.route,
                onNavigate = { route -> navController.navigate(route) }
            )
        }
    ) { innerPadding ->
        Column(modifier = Modifier.padding(innerPadding).verticalScroll(scrollState)) {
            // Screen contents
        }
    }
}`
                    }
                  ]
                }
              ]
            },
            {
              name: "navigation",
              files: [
                {
                  name: "Screen.kt",
                  path: "app/src/main/java/com/aurawavex/app/navigation/Screen.kt",
                  content: `package com.aurawavex.app.navigation

/**
 * Screen
 * Sealed class mapping application destination routes.
 * Powered by HoloCore™
 */
sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object Home : Screen("home")
    object Music : Screen("music")
    object HoloCore : Screen("holocore")
    object Equalizer : Screen("equalizer")
    object Analyzer : Screen("analyzer")
    object Settings : Screen("settings")
}`
                },
                {
                  name: "NavGraph.kt",
                  path: "app/src/main/java/com/aurawavex/app/navigation/NavGraph.kt",
                  content: `package com.aurawavex.app.navigation

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.aurawavex.app.ui.screens.*
import com.aurawavex.app.viewmodel.AudioViewModel
import com.aurawavex.app.viewmodel.DacViewModel

@Composable
fun AuraWaveXNavigation(
    audioViewModel: AudioViewModel,
    dacViewModel: DacViewModel
) {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = Screen.Splash.route) {
        composable(Screen.Splash.route) {
            SplashScreen { navController.navigate(Screen.Home.route) }
        }
        composable(Screen.Home.route) {
            HomeScreen(navController, audioViewModel, dacViewModel)
        }
    }
}`
                }
              ]
            }
          ]
        },
        {
          name: "build-system",
          files: [
            {
              name: "build.gradle.kts",
              path: "app/build.gradle.kts",
              content: `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.aurawavex.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.aurawavex.app"
        minSdk = 29
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("debug") // Simulated high-end build configs
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
        freeCompilerArgs += listOf(
            "-opt-in=androidx.compose.material3.ExperimentalMaterial3Api",
            "-opt-in=kotlinx.coroutines.ExperimentalCoroutinesApi"
        )
    }
    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.8"
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    // Jetpack Compose Foundation & UI
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
    implementation("androidx.activity:activity-compose:1.8.2")
    implementation(platform("androidx.compose:compose-bom:2024.02.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.navigation:navigation-compose:2.7.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.7.0")

    // Luxury Low Latency / Audio SDKs
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")

    // Testing suite
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")
}
`
            }
          ]
        }
      ]
    }
  ]
};
