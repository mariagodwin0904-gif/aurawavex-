package com.aurawavex.app.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurawavex.app.ui.theme.ElectricBlue
import com.aurawavex.app.ui.theme.DeepPurple
import kotlinx.coroutines.delay
import kotlin.math.sin

/**
 * SplashScreen
 * Fades in a luxury dynamic logo that simulates wave particle motion.
 * Powered by HoloCore™
 */
@Composable
fun SplashScreen(onSplashCompleted: () -> Unit) {
    val scale = remember { Animatable(0.7f) }
    val alpha = remember { Animatable(0.0f) }
    val subtitleAlpha = remember { Animatable(0.0f) }

    val infiniteTransition = rememberInfiniteTransition(label = "wave_particles")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (Math.PI * 2).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ), label = "wave_phase"
    )

    LaunchedEffect(Unit) {
        // Run concurrent logo & title animations
        scale.animateTo(
            targetValue = 1.0f,
            animationSpec = tween(1200, easing = EaseOutCubic)
        )
        alpha.animateTo(
            targetValue = 1.0f,
            animationSpec = tween(1000)
        )
        subtitleAlpha.animateTo(
            targetValue = 0.8f,
            animationSpec = tween(800, delayMillis = 600)
        )
        
        delay(2500) // Audiophile luxury delay
        onSplashCompleted()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Animated Luxury Particle Wave Circle
            Box(
                modifier = Modifier
                    .size(160.dp)
                    .alpha(alpha.value),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val radius = size.minDimension / 3f
                    val center = Offset(size.width / 2f, size.height / 2f)

                    // Draw glowing luxury mesh circles
                    for (i in 0 until 40) {
                        val angle = (i * Math.PI * 2 / 40).toFloat()
                        val waveOffset = sin(angle * 4 + phase) * 12f
                        val currentRadius = radius + waveOffset

                        val x = center.x + kotlin.math.cos(angle) * currentRadius
                        val y = center.y + sin(angle) * currentRadius

                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(ElectricBlue, Color.Transparent),
                                center = Offset(x, y),
                                radius = 10f
                            ),
                            radius = 6f,
                            center = Offset(x, y)
                        )
                    }

                    // Inner Purple Core Ring
                    drawCircle(
                        color = DeepPurple.copy(alpha = 0.3f),
                        radius = radius - 8f,
                        center = center
                    )
                }
            }

            Spacer(modifier = Modifier.height(40.dp))

            // AuraWaveX Title
            Text(
                text = "AURAWA VEX",
                fontSize = 28.sp,
                letterSpacing = 12.sp,
                fontWeight = FontWeight.Light,
                color = Color.White,
                modifier = Modifier
                    .alpha(alpha.value)
                    .padding(start = 12.dp) // Balance letter-spacing offset
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Powered by HoloCore™
            Text(
                text = "POWERED BY HOLOCORE™",
                fontSize = 11.sp,
                letterSpacing = 4.sp,
                fontWeight = FontWeight.Medium,
                color = ElectricBlue,
                modifier = Modifier.alpha(subtitleAlpha.value)
            )
        }
    }
}
