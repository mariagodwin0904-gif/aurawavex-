package com.aurawavex.app.viewmodel

import androidx.lifecycle.ViewModel
import com.aurawavex.app.model.AudioDriver
import com.aurawavex.app.model.DacConnectionStatus
import com.aurawavex.app.model.DacFilter
import com.aurawavex.app.model.DacState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * DacViewModel
 * Manages configuration, voltage scaling, bit-perfect routing, and digital filter selection of the DAC.
 * Powered by HoloCore™
 */
class DacViewModel : ViewModel() {

    private val _dacState = MutableStateFlow(DacState())
    val dacState: StateFlow<DacState> = _dacState.asStateFlow()

    fun setDacConnection(status: DacConnectionStatus) {
        _dacState.update { current ->
            current.copy(
                status = status,
                modelName = when (status) {
                    DacConnectionStatus.DISCONNECTED -> "No Audio Hardware Detected"
                    DacConnectionStatus.CONNECTING -> "Handshaking..."
                    DacConnectionStatus.CONNECTED_INTERNAL -> "Qualcomm WCD9385 Built-in DAC"
                    DacConnectionStatus.CONNECTED_USB -> "HoloCore™ Reference DAC-X1"
                }
            )
        }
    }

    fun setAudioDriver(driver: AudioDriver) {
        _dacState.update { current ->
            current.copy(
                driver = driver,
                isBitPerfect = driver == AudioDriver.BIT_PERFECT_USB || driver == AudioDriver.DIRECT_DSD
            )
        }
    }

    fun setDacFilter(filter: DacFilter) {
        _dacState.update { it.copy(filter = filter) }
    }

    fun updateVolume(step: Int) {
        _dacState.update { current ->
            val cleanStep = step.coerceIn(0, current.maxVolumeSteps)
            current.copy(
                volumeStep = cleanStep,
                voltageVrms = (cleanStep.toDouble() / current.maxVolumeSteps) * 2.5
            )
        }
    }

    fun toggleBitPerfect() {
        _dacState.update { current ->
            val nextBp = !current.isBitPerfect
            val driver = if (nextBp) AudioDriver.BIT_PERFECT_USB else AudioDriver.STANDARD
            current.copy(
                isBitPerfect = nextBp,
                driver = driver
            )
        }
    }
}
