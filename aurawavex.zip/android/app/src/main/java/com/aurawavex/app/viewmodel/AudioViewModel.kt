package com.aurawavex.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aurawavex.app.model.Song
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * AudioViewModel
 * Manages the high-resolution audiophile audio track queue and simulated audio playback.
 * Powered by HoloCore™
 */
class AudioViewModel : ViewModel() {

    private val trackList = listOf(
        Song(
            id = "track_1",
            title = "Aether Waves",
            artist = "Luminance Duo",
            album = "Quantum Echoes",
            durationSeconds = 342,
            sampleRateHz = 192000,
            bitDepth = 24,
            fileFormat = "FLAC",
            kbps = 5820,
            coverArtPlaceholderHex = "#0C1424"
        ),
        Song(
            id = "track_2",
            title = "Nebula Dreams",
            artist = "Cosmic Synthesis",
            album = "Stellar Audio Experience",
            durationSeconds = 485,
            sampleRateHz = 352800,
            bitDepth = 32,
            fileFormat = "WAV",
            kbps = 9216,
            coverArtPlaceholderHex = "#160C24"
        ),
        Song(
            id = "track_3",
            title = "Absolute Horizon (Master Edition)",
            artist = "Vortex Field",
            album = "HoloCore Showcase Vol. I",
            durationSeconds = 294,
            sampleRateHz = 2822400, // DSD64
            bitDepth = 1,
            fileFormat = "DSD",
            kbps = 5644,
            coverArtPlaceholderHex = "#0D1E16"
        )
    )

    private val _currentSong = MutableStateFlow(trackList[0])
    val currentSong: StateFlow<Song> = _currentSong.asStateFlow()

    private val _isPlaying = MutableStateFlow(true)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentProgressSeconds = MutableStateFlow(42)
    val currentProgressSeconds: StateFlow<Int> = _currentProgressSeconds.asStateFlow()

    private var playbackJob: Job? = null

    init {
        startProgressSim()
    }

    private fun startProgressSim() {
        playbackJob?.cancel()
        playbackJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                if (_isPlaying.value) {
                    val nextSec = _currentProgressSeconds.value + 1
                    if (nextSec >= _currentSong.value.durationSeconds) {
                        nextTrack()
                    } else {
                        _currentProgressSeconds.value = nextSec
                    }
                }
            }
        }
    }

    fun togglePlayPause() {
        _isPlaying.value = !_isPlaying.value
    }

    fun nextTrack() {
        val currentIndex = trackList.indexOf(_currentSong.value)
        val nextIndex = (currentIndex + 1) % trackList.size
        _currentSong.value = trackList[nextIndex]
        _currentProgressSeconds.value = 0
    }

    fun prevTrack() {
        val currentIndex = trackList.indexOf(_currentSong.value)
        var prevIndex = currentIndex - 1
        if (prevIndex < 0) prevIndex = trackList.size - 1
        _currentSong.value = trackList[prevIndex]
        _currentProgressSeconds.value = 0
    }

    fun getSongs(): List<Song> = trackList

    fun selectSong(song: Song) {
        _currentSong.value = song
        _currentProgressSeconds.value = 0
        _isPlaying.value = true
    }

    override fun onCleared() {
        super.onCleared()
        playbackJob?.cancel()
    }
}
