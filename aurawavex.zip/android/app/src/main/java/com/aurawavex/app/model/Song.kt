package com.aurawavex.app.model

/**
 * Song
 * Represents a high-resolution audiophile track.
 * Powered by HoloCore™
 */
data class Song(
    val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val durationSeconds: Int,
    val sampleRateHz: Int,
    val bitDepth: Int,
    val fileFormat: String, // FLAC, DSD, WAV, MQA
    val kbps: Int,
    val isHiRes: Boolean = true,
    val coverArtPlaceholderHex: String = "#0D0D12"
) {
    val displaySampleRate: String
        get() = if (fileFormat == "DSD") {
            "DSD${sampleRateHz / 44100}"
        } else {
            "${sampleRateHz / 1000.0} kHz"
        }

    val displayBitDepth: String
        get() = if (fileFormat == "DSD") "1-bit" else "$bitDepth-bit"
}
