package com.aurawavex.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.aurawavex.app.navigation.Screen
import com.aurawavex.app.ui.theme.*
import com.aurawavex.app.viewmodel.AudioViewModel

/**
 * MusicScreen
 * Displays high-resolution files available for playback.
 * Powered by HoloCore™
 */
@Composable
fun MusicScreen(
    navController: NavController,
    audioViewModel: AudioViewModel
) {
    val songs = audioViewModel.getSongs()
    val currentSong by audioViewModel.currentSong.collectAsState()

    Scaffold(
        bottomBar = {
            AuraWaveXBottomBar(
                currentRoute = Screen.Music.route,
                onNavigate = { route ->
                    navController.navigate(route) {
                        launchSingleTop = true
                        popUpTo(Screen.Home.route)
                    }
                }
            )
        },
        containerColor = AmoledBlack
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(AmoledBlack)
                .padding(horizontal = 20.dp, vertical = 16.dp)
        ) {
            Text(
                text = "Hi-Res Library",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Light,
                color = Color.White
            )
            Text(
                text = "DIRECT HARDWARE STORAGE INTERFACE",
                style = MaterialTheme.typography.labelSmall,
                color = ElectricBlue
            )

            Spacer(modifier = Modifier.height(20.dp))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(songs) { song ->
                    val isSelected = song.id == currentSong.id
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (isSelected) GlassCardPressed else GlassBackground)
                            .border(1.dp, if (isSelected) ElectricBlue else GlassBorder, RoundedCornerShape(16.dp))
                            .clickable { audioViewModel.selectSong(song) }
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = song.title,
                                style = MaterialTheme.typography.titleMedium,
                                color = if (isSelected) ElectricBlue else Color.White
                            )
                            Text(
                                text = song.artist,
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = song.fileFormat,
                                style = MaterialTheme.typography.labelLarge,
                                color = if (isSelected) ElectricBlue else TextMuted
                            )
                            Text(
                                text = song.displaySampleRate,
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted
                            )
                        }
                    }
                }
            }
        }
    }
}
