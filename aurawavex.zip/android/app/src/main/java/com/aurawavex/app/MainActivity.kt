package com.aurawavex.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.core.view.WindowCompat
import com.aurawavex.app.ui.theme.AuraWaveXTheme
import com.aurawavex.app.navigation.AuraWaveXNavigation
import com.aurawavex.app.viewmodel.AudioViewModel
import com.aurawavex.app.viewmodel.DacViewModel

/**
 * MainActivity
 * Entry point for AuraWaveX.
 * Configures edge-to-edge rendering, initializes core view models, and bootstraps the AuraWaveX navigation graph.
 * 
 * Powered by HoloCore™
 * Developed by Chrissy Godwin
 */
class MainActivity : ComponentActivity() {
    
    private val audioViewModel: AudioViewModel by viewModels()
    private val dacViewModel: DacViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Enable edge-to-edge system bars integration
        WindowCompat.setDecorFitsSystemWindows(window, false)

        setContent {
            AuraWaveXTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AuraWaveXNavigation(
                        audioViewModel = audioViewModel,
                        dacViewModel = dacViewModel
                    )
                }
            }
        }
    }
}
