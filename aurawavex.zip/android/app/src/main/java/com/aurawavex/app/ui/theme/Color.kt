package com.aurawavex.app.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * AuraWaveX Luxury Color Palette
 * Powered by HoloCore™
 */

// Pure AMOLED Black Canvas
val AmoledBlack = Color(0xFF000000)
val DarkGreyBg = Color(0xFF08080A)

// Luxury Accents
val ElectricBlue = Color(0xFF00E5FF)
val ElectricBlueGlow = Color(0x3300E5FF)
val DeepPurple = Color(0xFF8E24AA)
val DeepPurpleGlow = Color(0x338E24AA)

// Neutral Text & Icons
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xB3FFFFFF)
val TextMuted = Color(0x80FFFFFF)

// Glassmorphism System
val GlassBackground = Color(0x12FFFFFF)
val GlassBorder = Color(0x1AFFFFFF)
val GlassCardPressed = Color(0x26FFFFFF)

// Functional Statuses
val DacActiveGlow = Color(0xFF00E5FF)
val DacStandbyGlow = Color(0xFFFFB300)
val DacHiResColor = Color(0xFF00E5FF)
val DacMqaColor = Color(0xFFD500F9)
val DacBitPerfectColor = Color(0xFF00E676)
