package com.aurawavex.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.aurawavex.app.navigation.Screen
import com.aurawavex.app.ui.theme.*

/**
 * AnalyzerScreen
 * Real-time fast Fourier transform (FFT) spectrum analyser.
 * Powered by HoloCore™
 */
@Composable
fun AnalyzerScreen(navController: NavController) {
    Scaffold(
        bottomBar = {
            AuraWaveXBottomBar(
                currentRoute = Screen.Analyzer.route,
                onNavigate = { route ->
                    navController.navigate(route) {
                        launchSingleTop = true
                        popUpTo(Screen.Home.route)
                    }
                }
            )
        },
        containerColor = AmoledBlack
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(AmoledBlack)
                .padding(horizontal = 20.dp, vertical = 16.dp)
        ) {
            Text(
                text = "FFT Spectrum",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Light,
                color = Color.White
            )
            Text(
                text = "OCTAVE-BAND SPECTRUM REALTIME FFT ANALYZER",
                style = MaterialTheme.typography.labelSmall,
                color = ElectricBlue
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Gorgeous spectrum area
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(24.dp))
                    .background(GlassBackground)
                    .border(1.dp, GlassBorder, RoundedCornerShape(24.dp))
                    .padding(20.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "HARDWARE FFT RENDER CANVAS",
                    style = MaterialTheme.typography.labelLarge,
                    color = ElectricBlue
                )
            }
        }
    }
}
