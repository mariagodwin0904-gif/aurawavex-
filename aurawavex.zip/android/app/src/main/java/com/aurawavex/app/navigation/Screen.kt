package com.aurawavex.app.navigation

/**
 * Screen
 * Sealed class mapping application destination routes.
 * Powered by HoloCore™
 */
sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object Home : Screen("home")
    object Music : Screen("music")
    object HoloCore : Screen("holocore")
    object Equalizer : Screen("equalizer")
    object Analyzer : Screen("analyzer")
    object Settings : Screen("settings")
}
