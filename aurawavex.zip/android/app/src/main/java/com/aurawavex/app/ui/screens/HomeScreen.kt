package com.aurawavex.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.aurawavex.app.navigation.Screen
import com.aurawavex.app.ui.theme.*
import com.aurawavex.app.viewmodel.AudioViewModel
import com.aurawavex.app.viewmodel.DacViewModel

/**
 * HomeScreen
 * The flagship hub of AuraWaveX.
 * Integrates real-time audio parameters, active waveform rendering, and DAC metrics.
 * Powered by HoloCore™
 */
@Composable
fun HomeScreen(
    navController: NavController,
    audioViewModel: AudioViewModel,
    dacViewModel: DacViewModel
) {
    val currentSong by audioViewModel.currentSong.collectAsState()
    val isPlaying by audioViewModel.isPlaying.collectAsState()
    val currentProgress by audioViewModel.currentProgressSeconds.collectAsState()
    val dacState by dacViewModel.dacState.collectAsState()

    val scrollState = rememberScrollState()

    Scaffold(
        bottomBar = {
            AuraWaveXBottomBar(
                currentRoute = Screen.Home.route,
                onNavigate = { route ->
                    if (route != Screen.Home.route) {
                        navController.navigate(route) {
                            launchSingleTop = true
                        }
                    }
                }
            )
        },
        containerColor = AmoledBlack
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(AmoledBlack)
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top branding bar
            HeaderBranding()

            Spacer(modifier = Modifier.height(24.dp))

            // Animated Real-Time Audio Waveform
            InteractiveWaveformContainer(isPlaying = isPlaying)

            Spacer(modifier = Modifier.height(24.dp))

            // Current Sample Rate & Bit Depth Indicators
            DacIndicatorsRow(
                sampleRate = currentSong.displaySampleRate,
                bitDepth = currentSong.displayBitDepth,
                format = currentSong.fileFormat,
                isBitPerfect = dacState.isBitPerfect
            )

            Spacer(modifier = Modifier.height(20.dp))

            // DAC Status Card
            DacStatusCard(
                modelName = dacState.modelName,
                driverName = dacState.driver.displayName,
                filterName = dacState.filter.displayName,
                voltage = dacState.voltageVrms,
                volumeStep = dacState.volumeStep,
                mqaStatus = dacState.mqaStatus,
                isBitPerfect = dacState.isBitPerfect,
                onClick = { navController.navigate(Screen.HoloCore.route) }
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Current Song Card
            CurrentSongCard(
                title = currentSong.title,
                artist = currentSong.artist,
                album = currentSong.album,
                progress = currentProgress,
                duration = currentSong.durationSeconds,
                isPlaying = isPlaying,
                kbps = currentSong.kbps,
                coverHex = currentSong.coverArtPlaceholderHex,
                onPlayPauseToggle = { audioViewModel.togglePlayPause() },
                onNextTrack = { audioViewModel.nextTrack() },
                onPrevTrack = { audioViewModel.prevTrack() },
                onClick = { navController.navigate(Screen.Music.route) }
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Centered, elegant luxury footer
            DevelopedByFooter()

            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}

@Composable
fun HeaderBranding() {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "AURAWA VEX",
            style = MaterialTheme.typography.titleLarge.copy(
                fontWeight = FontWeight.Light,
                letterSpacing = 8.sp,
                color = Color.White
            )
        )
        Text(
            text = "POWERED BY HOLOCORE™",
            style = MaterialTheme.typography.labelSmall.copy(
                letterSpacing = 2.sp,
                color = ElectricBlue,
                fontWeight = FontWeight.Bold
            )
        )
    }
}

@Composable
fun InteractiveWaveformContainer(isPlaying: Boolean) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(130.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(GlassBackground)
            .border(1.dp, GlassBorder, RoundedCornerShape(20.dp))
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        // Compose Live Waveform drawing or placeholder simulation
        Text(
            text = if (isPlaying) "HOLOCORE™ ACTIVE DECODING WAVE" else "AUDIO ENGINE SUSPENDED",
            style = MaterialTheme.typography.labelSmall.copy(
                color = if (isPlaying) ElectricBlue else TextMuted,
                letterSpacing = 1.sp
            ),
            modifier = Modifier.align(Alignment.TopCenter)
        )
        
        // Simulating the dynamic wave bars inside Kotlin
        Row(
            modifier = Modifier
                .fillMaxWidth(0.85f)
                .height(60.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Sample list of waveform bars that would animate based on playback
            val barsCount = 32
            for (i in 0 until barsCount) {
                val heightMultiplier = if (isPlaying) {
                    remember { mutableStateOf((20..100).random()) }
                    // Dynamic updates would happen via transition state
                } else {
                    remember { mutableStateOf(15) }
                }
                Box(
                    modifier = Modifier
                        .width(4.dp)
                        .fillMaxHeight(heightMultiplier.value / 100f)
                        .clip(RoundedCornerShape(2.dp))
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(ElectricBlue, DeepPurple)
                            )
                        )
                )
            }
        }
    }
}

@Composable
fun DacIndicatorsRow(
    sampleRate: String,
    bitDepth: String,
    format: String,
    isBitPerfect: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        IndicatorBadge(label = "RATE", value = sampleRate)
        IndicatorBadge(label = "DEPTH", value = bitDepth)
        IndicatorBadge(label = "FORMAT", value = format)
        IndicatorBadge(
            label = "DRIVER",
            value = if (isBitPerfect) "BIT-PERFECT" else "MAPPED",
            highlightColor = if (isBitPerfect) ElectricBlue else TextSecondary
        )
    }
}

@Composable
fun IndicatorBadge(
    label: String,
    value: String,
    highlightColor: Color = Color.White
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(GlassBackground)
            .border(1.dp, GlassBorder, RoundedCornerShape(12.dp))
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = TextMuted
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.labelLarge.copy(
                fontWeight = FontWeight.SemiBold,
                color = highlightColor
            )
        )
    }
}

@Composable
fun DacStatusCard(
    modelName: String,
    driverName: String,
    filterName: String,
    voltage: Double,
    volumeStep: Int,
    mqaStatus: String,
    isBitPerfect: Boolean,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(GlassBackground)
            .border(1.dp, GlassBorder, RoundedCornerShape(24.dp))
            .clickable { onClick() }
            .padding(20.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Map
        ) {
            Text(
                text = "HOLOCORE™ DAC STATUS",
                style = MaterialTheme.typography.labelSmall,
                color = ElectricBlue,
                fontWeight = FontWeight.Bold
            )
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (isBitPerfect) ElectricBlue else Color.Yellow)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = modelName,
            style = MaterialTheme.typography.titleLarge,
            color = Color.White
        )

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(text = "DIGITAL FILTER", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                Text(text = filterName, style = MaterialTheme.typography.bodyMedium, color = Color.White)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(text = "OUTPUT LEVEL", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                Text(text = String.format("%.2f Vrms", voltage), style = MaterialTheme.typography.bodyMedium, color = Color.White)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(text = "AUDIO DRIVER", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                Text(text = driverName, style = MaterialTheme.typography.bodyMedium, color = Color.White)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(text = "VOLUME COARSE", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                Text(text = "$volumeStep / 120 Steps", style = MaterialTheme.typography.bodyMedium, color = ElectricBlue)
            }
        }
    }
}

@Composable
fun CurrentSongCard(
    title: String,
    artist: String,
    album: String,
    progress: Int,
    duration: Int,
    isPlaying: Boolean,
    kbps: Int,
    coverHex: String,
    onPlayPauseToggle: () -> Unit,
    onNextTrack: () -> Unit,
    onPrevTrack: () -> Unit,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(GlassBackground)
            .border(1.dp, GlassBorder, RoundedCornerShape(24.dp))
            .clickable { onClick() }
            .padding(20.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Simulated Luxury cover art
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(android.graphics.Color.parseColor(coverHex)))
                    .border(1.dp, GlassBorder, RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Hi-Res",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = ElectricBlue,
                        fontWeight = FontWeight.Bold
                    )
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    color = Color.White
                )
                Text(
                    text = "$artist — $album",
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 1,
                    color = TextSecondary
                )
                Text(
                    text = "$kbps kbps Lossless",
                    style = MaterialTheme.typography.labelSmall,
                    color = ElectricBlue
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Progress slider placeholder (composed cleanly)
        LinearProgressIndicator(
            progress = { progress.toFloat() / duration },
            modifier = Modifier
                .fillMaxWidth()
                .height(4.dp)
                .clip(RoundedCornerShape(2.dp)),
            color = ElectricBlue,
            trackColor = GlassBorder,
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = String.format("%02d:%02d", progress / 60, progress % 60),
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted
            )
            Text(
                text = String.format("%02d:%02d", duration / 60, duration % 60),
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Premium Audio Controls Layout
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "PREV",
                modifier = Modifier
                    .clickable { onPrevTrack() }
                    .padding(16.dp),
                style = MaterialTheme.typography.labelLarge.copy(color = Color.White)
            )
            Spacer(modifier = Modifier.width(24.dp))
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .background(ElectricBlue)
                    .clickable { onPlayPauseToggle() },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (isPlaying) "PAUSE" else "PLAY",
                    style = MaterialTheme.typography.labelLarge.copy(
                        color = AmoledBlack,
                        fontWeight = FontWeight.Bold
                    )
                )
            }
            Spacer(modifier = Modifier.width(24.dp))
            Text(
                text = "NEXT",
                modifier = Modifier
                    .clickable { onNextTrack() }
                    .padding(16.dp),
                style = MaterialTheme.typography.labelLarge.copy(color = Color.White)
            )
        }
    }
}

@Composable
fun DevelopedByFooter() {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "DEVELOPED BY CHRISSY GODWIN",
            style = MaterialTheme.typography.labelSmall.copy(
                letterSpacing = 3.sp,
                color = TextMuted,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold
            ),
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun AuraWaveXBottomBar(
    currentRoute: String,
    onNavigate: (String) -> Unit
) {
    // Custom bottom nav representing the layout
    NavigationBar(
        containerColor = AmoledBlack,
        tonalElevation = 0.dp,
        modifier = Modifier.border(top = 1.dp, brush = Brush.verticalGradient(listOf(GlassBorder, Color.Transparent)))
    ) {
        val navItems = listOf(
            Screen.Home to "Home",
            Screen.Music to "Music",
            Screen.HoloCore to "HoloCore",
            Screen.Equalizer to "EQ",
            Screen.Analyzer to "Analyzer",
            Screen.Settings to "Settings"
        )
        
        navItems.forEach { (screen, label) ->
            val isSelected = currentRoute == screen.route
            NavigationBarItem(
                selected = isSelected,
                onClick = { onNavigate(screen.route) },
                icon = {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(RoundedCornerShape(5.dp))
                            .background(if (isSelected) ElectricBlue else TextMuted)
                    )
                },
                label = {
                    Text(
                        text = label,
                        fontSize = 10.sp,
                        color = if (isSelected) Color.White else TextMuted
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = GlassBackground
                )
            )
        }
    }
}
