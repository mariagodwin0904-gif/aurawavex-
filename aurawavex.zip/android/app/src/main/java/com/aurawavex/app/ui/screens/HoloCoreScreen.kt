package com.aurawavex.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.aurawavex.app.model.AudioDriver
import com.aurawavex.app.model.DacFilter
import com.aurawavex.app.navigation.Screen
import com.aurawavex.app.ui.theme.*
import com.aurawavex.app.viewmodel.AudioViewModel
import com.aurawavex.app.viewmodel.DacViewModel

/**
 * HoloCoreScreen
 * Provides extreme customization of the DAC hardware and driver configuration.
 * Powered by HoloCore™
 */
@Composable
fun HoloCoreScreen(
    navController: NavController,
    dacViewModel: DacViewModel,
    audioViewModel: AudioViewModel
) {
    val dacState by dacViewModel.dacState.collectAsState()
    val scrollState = rememberScrollState()

    Scaffold(
        bottomBar = {
            AuraWaveXBottomBar(
                currentRoute = Screen.HoloCore.route,
                onNavigate = { route ->
                    navController.navigate(route) {
                        launchSingleTop = true
                        popUpTo(Screen.Home.route)
                    }
                }
            )
        },
        containerColor = AmoledBlack
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(AmoledBlack)
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp, vertical = 16.dp)
        ) {
            Text(
                text = "HoloCore™ Engine",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Light,
                color = Color.White
            )
            Text(
                text = "DSP & DRIVER DIRECT HARDWARE MATRIX",
                style = MaterialTheme.typography.labelSmall,
                color = ElectricBlue
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Toggle Bit-Perfect Mode Card
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(GlassBackground)
                    .border(1.dp, if (dacState.isBitPerfect) ElectricBlue else GlassBorder, RoundedCornerShape(20.dp))
                    .clickable { dacViewModel.toggleBitPerfect() }
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Bit-Perfect Mode",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White
                        )
                        Text(
                            text = "Bypasses all Android OS sound mixer layers",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                    }
                    Switch(
                        checked = dacState.isBitPerfect,
                        onCheckedChange = { dacViewModel.toggleBitPerfect() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = AmoledBlack,
                            checkedTrackColor = ElectricBlue
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Driver Choice Selection
            Text(
                text = "SELECT AUDIO DRIVER",
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted
            )
            Spacer(modifier = Modifier.height(8.dp))

            AudioDriver.values().forEach { driver ->
                val isSelected = dacState.driver == driver
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isSelected) GlassCardPressed else GlassBackground)
                        .border(1.dp, if (isSelected) ElectricBlue else GlassBorder, RoundedCornerShape(12.dp))
                        .clickable { dacViewModel.setAudioDriver(driver) }
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = driver.displayName,
                        style = MaterialTheme.typography.bodyLarge,
                        color = if (isSelected) Color.White else TextSecondary
                    )
                    if (isSelected) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(RoundedCornerShape(5.dp))
                                .background(ElectricBlue)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // DAC Interpolation Filters
            Text(
                text = "DAC INTERPOLATION FILTERS (ANTI-ALIASING)",
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted
            )
            Spacer(modifier = Modifier.height(8.dp))

            DacFilter.values().forEach { filter ->
                val isSelected = dacState.filter == filter
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isSelected) GlassCardPressed else GlassBackground)
                        .border(1.dp, if (isSelected) ElectricBlue else GlassBorder, RoundedCornerShape(12.dp))
                        .clickable { dacViewModel.setDacFilter(filter) }
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = filter.displayName,
                        style = MaterialTheme.typography.bodyLarge,
                        color = if (isSelected) Color.White else TextSecondary
                    )
                    if (isSelected) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(RoundedCornerShape(5.dp))
                                .background(ElectricBlue)
                        )
                    }
                }
            }
        }
    }
}
