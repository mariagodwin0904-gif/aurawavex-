package com.aurawavex.app.model

/**
 * DacConnectionStatus
 */
enum class DacConnectionStatus {
    DISCONNECTED,
    CONNECTING,
    CONNECTED_INTERNAL,
    CONNECTED_USB
}

/**
 * DacFilter
 */
enum class DacFilter(val displayName: String) {
    FAST_ROLL_OFF("Fast Roll-Off (Linear)"),
    SLOW_ROLL_OFF("Slow Roll-Off (Linear)"),
    MINIMUM_PHASE("Minimum Phase (Fast)"),
    APODIZING("Apodizing Fast Roll-Off"),
    HYBRID_FAST("Hybrid Fast Roll-Off")
}

/**
 * AudioDriver
 */
enum class AudioDriver(val displayName: String) {
    STANDARD("Standard (AAudio)"),
    BIT_PERFECT_USB("HoloCore™ Bit-Perfect USB"),
    DIRECT_DSD("HoloCore™ Native DSD Direct")
}

/**
 * DacState
 * Holds real-time stats of the current digital-to-analog converter hardware.
 * Powered by HoloCore™
 */
data class DacState(
    val status: DacConnectionStatus = DacConnectionStatus.CONNECTED_USB,
    val modelName: String = "HoloCore™ Reference DAC-X1",
    val driver: AudioDriver = AudioDriver.BIT_PERFECT_USB,
    val filter: DacFilter = DacFilter.MINIMUM_PHASE,
    val sampleRateHz: Int = 192000,
    val bitDepth: Int = 24,
    val isBitPerfect: Boolean = true,
    val mqaStatus: String = "MQA Studio Decoder",
    val voltageVrms: Double = 2.2,
    val volumeStep: Int = 85,
    val maxVolumeSteps: Int = 120
)
