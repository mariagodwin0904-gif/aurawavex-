package com.aurawavex.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.aurawavex.app.navigation.Screen
import com.aurawavex.app.ui.theme.*

/**
 * EqScreen
 * Parametric Equalizer configuration workspace.
 * Powered by HoloCore™
 */
@Composable
fun EqScreen(navController: NavController) {
    Scaffold(
        bottomBar = {
            AuraWaveXBottomBar(
                currentRoute = Screen.Equalizer.route,
                onNavigate = { route ->
                    navController.navigate(route) {
                        launchSingleTop = true
                        popUpTo(Screen.Home.route)
                    }
                }
            )
        },
        containerColor = AmoledBlack
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(AmoledBlack)
                .padding(horizontal = 20.dp, vertical = 16.dp)
        ) {
            Text(
                text = "Parametric EQ",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Light,
                color = Color.White
            )
            Text(
                text = "64-BIT DOUBLE PRECISION FLOATING EQUALIZER",
                style = MaterialTheme.typography.labelSmall,
                color = ElectricBlue
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Beautiful placeholder cards representing parametric band control nodes
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(GlassBackground)
                    .border(1.dp, GlassBorder, RoundedCornerShape(20.dp))
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "EQ GRAPH INTERFACES READY",
                    style = MaterialTheme.typography.labelLarge,
                    color = TextMuted
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Band sliders placeholders
            val bands = listOf("31 Hz", "62 Hz", "125 Hz", "250 Hz", "500 Hz", "1 kHz", "2 kHz", "4 kHz", "8 kHz", "16 kHz")
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                bands.take(4).forEach { band ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = band,
                            modifier = Modifier.width(60.dp),
                            style = MaterialTheme.typography.labelLarge,
                            color = Color.White
                        )
                        Slider(
                            value = 0.5f,
                            onValueChange = {},
                            modifier = Modifier.weight(1f),
                            colors = SliderDefaults.colors(
                                thumbColor = ElectricBlue,
                                activeTrackColor = ElectricBlue
                            )
                        )
                    }
                }
            }
        }
    }
}
