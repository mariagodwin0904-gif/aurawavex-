package com.aurawavex.app.navigation

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.aurawavex.app.ui.screens.*
import com.aurawavex.app.viewmodel.AudioViewModel
import com.aurawavex.app.viewmodel.DacViewModel

/**
 * AuraWaveXNavigation
 * Navigation controller of AuraWaveX featuring 120Hz-ready luxury transition physics.
 * Powered by HoloCore™
 */
@Composable
fun AuraWaveXNavigation(
    audioViewModel: AudioViewModel,
    dacViewModel: DacViewModel
) {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = Screen.Splash.route
    ) {
        // Splash Screen with auto-forward delay
        composable(Screen.Splash.route) {
            SplashScreen(onSplashCompleted = {
                navController.navigate(Screen.Home.route) {
                    popUpTo(Screen.Splash.route) { inclusive = true }
                }
            })
        }

        // Home Screen
        composable(
            route = Screen.Home.route,
            enterTransition = {
                slideIntoContainer(
                    AnimatedContentTransitionScope.SlideDirection.Left,
                    animationSpec = tween(400)
                )
            },
            exitTransition = {
                slideOutOfContainer(
                    AnimatedContentTransitionScope.SlideDirection.Right,
                    animationSpec = tween(400)
                )
            }
        ) {
            HomeScreen(
                navController = navController,
                audioViewModel = audioViewModel,
                dacViewModel = dacViewModel
            )
        }

        // Music Library Screen
        composable(Screen.Music.route) {
            MusicScreen(
                navController = navController,
                audioViewModel = audioViewModel
            )
        }

        // HoloCore™ Audio Engine Control Screen
        composable(Screen.HoloCore.route) {
            HoloCoreScreen(
                navController = navController,
                dacViewModel = dacViewModel,
                audioViewModel = audioViewModel
            )
        }

        // Parametric Equalizer Screen
        composable(Screen.Equalizer.route) {
            EqScreen(
                navController = navController
            )
        }

        // 3D Spectrum Analyzer Screen
        composable(Screen.Analyzer.route) {
            AnalyzerScreen(
                navController = navController
            )
        }

        // Developer / Settings Screen
        composable(Screen.Settings.route) {
            SettingsScreen(
                navController = navController,
                dacViewModel = dacViewModel
            )
        }
    }
}
