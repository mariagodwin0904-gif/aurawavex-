package com.aurawavex.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.aurawavex.app.navigation.Screen
import com.aurawavex.app.ui.theme.*
import com.aurawavex.app.viewmodel.DacViewModel

/**
 * SettingsScreen
 * Hardware settings, buffer size tuning, and developer credits.
 * Powered by HoloCore™
 */
@Composable
fun SettingsScreen(
    navController: NavController,
    dacViewModel: DacViewModel
) {
    val scrollState = rememberScrollState()

    Scaffold(
        bottomBar = {
            AuraWaveXBottomBar(
                currentRoute = Screen.Settings.route,
                onNavigate = { route ->
                    navController.navigate(route) {
                        launchSingleTop = true
                        popUpTo(Screen.Home.route)
                    }
                }
            )
        },
        containerColor = AmoledBlack
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(AmoledBlack)
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp, vertical = 16.dp)
        ) {
            Text(
                text = "Settings",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Light,
                color = Color.White
            )
            Text(
                text = "HOLOCORE™ SYSTEM ARCHITECTURE CONTROLS",
                style = MaterialTheme.typography.labelSmall,
                color = ElectricBlue
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Hardware Buffer Section
            Text(
                text = "HARDWARE TUNING",
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted
            )
            Spacer(modifier = Modifier.height(8.dp))

            SettingToggleItem(title = "Hardware MQA Rendering", description = "Enables hardware MQA folding layers", initialValue = true)
            SettingToggleItem(title = "DSD Over PCM (DoP)", description = "Encapsulates native DSD streams inside PCM frames", initialValue = false)
            SettingToggleItem(title = "Exclusive USB Mode", description = "Gain absolute monopolistic access to external USB DACs", initialValue = true)

            Spacer(modifier = Modifier.height(24.dp))

            // About Section
            Text(
                text = "ABOUT SYSTEM",
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted
            )
            Spacer(modifier = Modifier.height(8.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(GlassBackground)
                    .border(1.dp, GlassBorder, RoundedCornerShape(16.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                AboutInfoRow(label = "Application Name", value = "AuraWaveX")
                AboutInfoRow(label = "Audio Core Engine", value = "HoloCore™ v4.2-Pro")
                AboutInfoRow(label = "Lead Architect", value = "Chrissy Godwin")
                AboutInfoRow(label = "UI Engine", value = "Jetpack Compose (120Hz Ready)")
                AboutInfoRow(label = "Build Target", value = "Android 10+ (API 29+)")
            }

            Spacer(modifier = Modifier.height(30.dp))
            DevelopedByFooter()
            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}

@Composable
fun SettingToggleItem(
    title: String,
    description: String,
    initialValue: Boolean
) {
    var checked by remember { mutableStateOf(initialValue) }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(GlassBackground)
            .border(1.dp, GlassBorder, RoundedCornerShape(12.dp))
            .padding(16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, style = MaterialTheme.typography.titleMedium, color = Color.White)
            Text(text = description, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
        }
        Switch(
            checked = checked,
            onCheckedChange = { checked = it },
            colors = SwitchDefaults.colors(
                checkedThumbColor = AmoledBlack,
                checkedTrackColor = ElectricBlue
            )
        )
    }
}

@Composable
fun AboutInfoRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
        Text(text = value, style = MaterialTheme.typography.labelLarge, color = Color.White)
    }
}
